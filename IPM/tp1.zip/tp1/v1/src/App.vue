<template>
  <div id="app">
    <LoginPage />
  </div>
</template>

<script>
import LoginPage from './components/LoginPage.vue';

export default {
  name: 'App',
  components: {
    LoginPage
  }
};
</script>
