// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import diretorRoutes from './diretor'
import alunosRoutes from './aluno'
import professorRoutes from './professor'

// Define rota base e de login
const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'Login', component: () => import('../views/Login.vue') },
  // Junta as rotas específicas para cada perfil
  ...diretorRoutes,
  ...alunosRoutes,
  ...professorRoutes,
  // Rota para NotFound (página não encontrada)
  { path: '/:pathMatch(.*)*', name: 'NotFound', component: () => import('../views/App.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
