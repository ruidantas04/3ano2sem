// src/router/diretor.js
const diretorRoutes = [
    {
      path: '/director',
      name: 'Director',
      component: () => import('../views/App.vue'),
      children: [
        { path: 'dashboard', name: 'DirectorDashboard', component: () => import('../views/App.vue') },
        { path: 'course/:courseId', name: 'DirectorCourse', component: () => import('../views/App.vue'), props: true },
        { path: 'course/:courseId/shift/:shiftId', name: 'DirectorShift', component: () => import('../views/App.vue'), props: true },
        { path: 'schedule', name: 'DirectorSchedule', component: () => import('../views/App.vue') },
        { path: 'student/:studentId', name: 'DirectorStudentProfile', component: () => import('../views/App.vue'), props: true },
        { path: 'manual-allocation', name: 'DirectorManualAllocation', component: () => import('../views/App.vue') },
        { path: 'requests', name: 'DirectorRequests', component: () => import('../views/App.vue') }
      ]
    }
  ]
  
  export default diretorRoutes
  