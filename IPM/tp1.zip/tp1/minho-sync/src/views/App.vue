<template>
  <router-view />
</template>

<script>
export default {
  name: 'MinhoSync'
}
</script>

<style>
/* Pode adicionar estilos globais aqui, se necessário */
</style>
