// Representa um Aluno
const Aluno = {
    id: null,
    name: '',
    email: '',
    password: '',
    specialStatus: false, // ou null se preferires
    enrolled: [] // array de IDs das UCs
  };
  
  export default Aluno;
  