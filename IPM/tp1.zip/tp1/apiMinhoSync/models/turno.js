// Representa um Turno (Shift)
const Turno = {
    id: null,
    courseId: null,
    classroomId: null,
    day: '',
    from: null,
    to: null,
    type: '', // por exemplo, "T" ou "PL"
    name: '',
    teacherId: null,
    totalStudentsRegistered: 0
  };
  
  export default Turno;
  