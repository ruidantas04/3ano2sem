// Representa uma Unidade Curricular (Curso)
const UnidadeCurricular = {
    id: null,
    name: '',
    abbreviation: '',
    year: null,
    semester: null,
    degreeId: null
  };
  
  export default UnidadeCurricular;
  