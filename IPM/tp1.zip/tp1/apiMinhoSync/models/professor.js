// Representa um Professor
const Professor = {
    id: null,
    name: '',
    email: '',
    password: ''
  };
  
  export default Professor;
  