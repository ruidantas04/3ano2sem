// Representa um Diretor
const Diretor = {
    id: null,
    name: '',
    email: '',
    password: ''
  };
  
  export default Diretor;
  