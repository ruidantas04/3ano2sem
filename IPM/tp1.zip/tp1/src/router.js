import { createRouter, createWebHistory } from 'vue-router';
import LoginPage from './components/LoginPage.vue';
import DirectorLayout from './minho-sync/src/views/Diretor.vue';
import Pedidos from './minho-sync/src/views/Pedidos.vue';

const routes = [
  { path: '/', name: 'Login', component: LoginPage },

  {
    path: '/director',
    name: 'Director',
    component: DirectorLayout,
    children: [
      {
        path: 'pedidos',
        name: 'Pedidos',
        component: Pedidos
      }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
