import { createRouter, createWebHistory } from 'vue-router';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {path: '/game',component: () => import('@/components/GamePage.vue')},
    {path: '/statistics',component: () => import('@/components/StatisticsPage.vue')},
    {path: '/simulation',component: () => import('@/components/SimulationPage.vue')},
  ]
});

export default router;