<template>
  <h2>Page not found...</h2>
</template>

<style scoped>
h2 {
  margin: 40px 0;
  text-align: center;
}
</style>