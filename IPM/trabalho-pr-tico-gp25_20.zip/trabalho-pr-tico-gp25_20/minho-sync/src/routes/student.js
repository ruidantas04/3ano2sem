// src/router/alunos.js
const alunosRoutes = [
  {
    path: '/student',
    name: 'Student',
    component: () => import('../views/student/StudentLayout.vue'),
    children: [
      { path: 'profile/:studentId', name: 'StudentProfile', component: () => import('../views/student/StudentProfile.vue'), props: true },
      { path: 'schedule', name: 'StudentSchedule', component: () => import('../views/student/Schedule.vue') },
      { path: 'request-form', name: 'StudentRequestForm', component: () => import('../views/student/RequestStudent.vue') }
    ]
  }
]

export default alunosRoutes
