// src/router/professor.js
const professorRoutes = [
    {
      path: '/teacher',
      name: 'Teacher',
      component: () => import('../views/teacher/TeacherLayout.vue'),
      children: [
        { path: '', name: 'TeacherDashboard', component: () => import('../views/teacher/Dashboard.vue') },
        { path: 'schedule', name: 'Schedule', component: () => import('../views/teacher/Schedule.vue') },
        { path: 'course/:courseId', name: 'TeacherCourse', component: () => import('../views/director/CourseDetail.vue'), props: true },
        { path: 'course/:courseId/shift/:shiftId', name: 'TeacherShift', component: () => import('../views/App.vue'), props: true },
        { path: 'request-form', name: 'TeacherRequestForm', component: () => import('../views/App.vue') }
      ]
    }
  ]
  
  export default professorRoutes
  