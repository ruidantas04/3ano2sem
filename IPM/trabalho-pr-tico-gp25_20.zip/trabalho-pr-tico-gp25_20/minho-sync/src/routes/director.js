// src/router/diretor.js
const diretorRoutes = [
  {
    path: '/director',
    name: 'Director',
    component: () => import('../views/director/DirectorLayout.vue'),
    children: [
      { path: 'dashboard', name: 'DirectorDashboard', component: () => import('../views/director/Dashboard.vue') },
      { path: 'course/:courseId', name: 'DirectorCourse', component: () => import('../views/director/CourseDetail.vue'), props: true },
      { path: 'course/:courseId/shift/:shiftId', name: 'DirectorShift', component: () => import('../views/director/ShiftDetail.vue'), props: true },
      { path: 'schedule', name: 'DirectorSchedule', component: () => import('../views/director/Schedule.vue') },
      { path: 'student/:studentId', name: 'DirectorStudentProfile', component: () => import('../views/student/StudentProfile.vue'), props: true },
      { path: 'student/:studentId/schedule', name: 'DirectorStudentSchedule', component: () => import('../views/director/StudentSchedule.vue'), props: true },
      { path: 'manual-allocation', name: 'DirectorManualAllocation', component: () => import('../views/director/ManualAllocation.vue') },
      { path: 'manual-UC-allocation/:year', name: 'a', component: () => import('../views/director/ManualAllocationUC.vue'), props: true },
      { path: 'requests', name: 'DirectorRequests', component: () => import('../views/director/Requests.vue') },
      { path: 'requests/classroom/:id', name: 'DirectorRequestDetailClassroom', component: () => import('../views/director/FormMudClassroom.vue'), props: true },
      { path: 'requests/shift/:id', name: 'DirectorRequestDetailShift', component: () => import('../views/director/FormMud.vue'), props: true },
    ]      
  }
]

export default diretorRoutes
