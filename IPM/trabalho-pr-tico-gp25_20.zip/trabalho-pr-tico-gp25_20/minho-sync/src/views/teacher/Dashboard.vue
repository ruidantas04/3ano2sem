<template>
<p1>Olá Futura dashboar</p1>
</template>
    
<script setup>

</script>