<template>
  <DirectorNavbar v-if="userType === 'director'" />
  <TeacherNavbar v-else-if="userType === 'teacher'" />
  <StudentNavbar v-else-if="userType === 'student'" />
  <DefaultNavbar v-else />
  
  <div class="p-8">
    <div class="flex flex-col lg:flex-row gap-3">
      <div class="bg-gray p-4 w-full lg:w-[350px] flex flex-col gap-4 rounded-lg shadow-md overflow-hidden">
        <SeletorTurnos @selection-change="handleSelectionChange" />
      </div>
      
      <div class="flex-1">
        <div class="bg-gray h-full rounded-lg shadow-md overflow-hidden p-4">
            <Horario
              :shiftIds="selectedShifts" 
              :yearFilter="yearFilter.length > 0 ? yearFilter : undefined"
            />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Horario from '/src/components/Horario.vue';
import SeletorTurnos from '/src/components/Seletor.vue';

import DirectorNavbar from '/src/components/director/navbar.vue';
import TeacherNavbar from '/src/components/teacher/navbar.vue';
import StudentNavbar from '/src/components/student/navbar.vue';
import DefaultNavbar from '/src/components/Navbar.vue'; 

const userType = ref(null);

const selectedShifts = ref([]);
const yearFilter = ref([]);

// Manipular mudança na seleção de turnos
const handleSelectionChange = (shifts) => {
  selectedShifts.value = shifts;
};

onMounted(() => {
  const storedUserType = localStorage.getItem('userType');
  userType.value = storedUserType;
});

</script>