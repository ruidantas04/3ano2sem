<template>
      <div class="flex items-center justify-center mt-[0px] px-[20px]">
      <div class="bg-white rounded-lg shadow-lg border border-dark-red p-8" style="width: 852px">
        <div class="max-w-[800px] mx-auto">
          <h1 class="text-2xl font-bold text-gray-800 text-center mb-3">Formulário de Pedido de Mudança</h1>
          <p class="text-gray-600 text-center mb-8">Preencha os detalhes do seu pedido</p>

          <div v-if="loading" class="text-center py-8">
            <svg class="animate-spin h-8 w-8 text-[#a21a1c] mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p class="mt-2 text-gray-600">Carregando dados...</p>
          </div>

          <div v-else-if="error" class="text-center py-8">
            <div class="text-red-500 mb-2">{{ error }}</div>
            <button 
              @click="loadData" 
              class="px-4 py-2 bg-[#a21a1c] text-white rounded-md hover:bg-[#b72a2c]"
            >
              Tentar novamente
            </button>
          </div>

          <form v-else class="space-y-6">
            <!-- E-mail -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-1"><strong>E-mail</strong></label>
              <div class="p-3 bg-gray-100 rounded-md shadow-sm" style="color: #666666; border: 1px solid #CCCCCC;">{{ student.email }}</div>
            </div>

            <!-- Assunto -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-1">Assunto</label>
              <div class="p-3 bg-gray-100 rounded-md shadow-sm" style="color: #666666; border: 1px solid #CCCCCC;">Mudança de turno</div>
            </div>

            <!-- Unidade Curricular -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-1">
                <strong>Unidade Curricular <span class="text-[#a21a1c]">*</span></strong>
              </label>
              <div class="relative">
                <select 
                  v-model="form.selectedCourseId" 
                  @change="loadCourseShifts"
                  class="w-full p-3 border rounded-md focus:ring-[#a21a1c] focus:border-[#a21a1c] shadow-sm appearance-none"
                  style="border-color: #CCCCCC;"
                >
                  <option disabled value="">Selecione a Unidade Curricular</option>
                  <option 
                    v-for="course in studentCourses" 
                    :key="course.id" 
                    :value="course.id"
                    class="p-2"
                  >
                    {{ course.name }}
                  </option>
                </select>
                <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg class="w-5 h-5 text-[#a21a1c]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Turno Atual -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-1"><strong>Turno Atual</strong></label>
              <div v-if="!form.selectedCourseId" class="p-3 bg-gray-100 border rounded-md shadow-sm" style="border-color: #CCCCCC;"></div>
              <div v-else-if="currentShift" class="p-3 bg-gray-100 rounded-md shadow-sm" style="border-color: #CCCCCC;">
                <p class="text-sm" style="color: #666666">
                  {{ currentShift }}
                </p>
              </div>
              <div v-else class="p-3 bg-gray-100 border rounded-md shadow-sm" style="border-color: #CCCCCC;"></div>
            </div>

            <!-- Turnos Disponíveis -->
            <div class="mb-6">
              <label class="block text-sm font-medium text-gray-700 mb-1">
                <strong>Turno disponível <span class="text-[#a21a1c]">*</span></strong>
              </label>
              <div class="relative">
                <select 
                  v-model="form.selectedNewShiftId" 
                  :disabled="!availableShifts.length"
                  class="w-full p-3 border rounded-md focus:ring-[#a21a1c] focus:border-[#a21a1c] shadow-sm appearance-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                  style="border-color: #CCCCCC;"
                >
                  <option disabled value="">Selecione o turno disponível</option>
                  <option 
                    v-for="shift in availableShifts" 
                    :key="shift.id" 
                    :value="shift.id"
                    class="p-2"
                  >
                    {{ shift.name }}
                  </option>
                </select>
                <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg class="w-5 h-5 text-[#a21a1c]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </div>
              </div>
              <p v-if="form.selectedCourseId && !availableShifts.length" class="text-sm text-red-500 mt-1">
                Não há turnos alternativos disponíveis para esta UC
              </p>
            </div>

            <!-- Botões -->
            <div class="flex justify-end space-x-4 mt-10 py-4">
              <button 
                type="button" 
                @click="resetForm"
                class="px-6 py-2.5 border border-gray-300 rounded-md text-black bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Cancelar
              </button>
              <button 
                type="submit" 
                @click.prevent="submitForm"
                :disabled="!formValid"
                class="px-6 py-2.5 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:cursor-not-allowed transition-colors duration-200"
                :class="formValid ? 'bg-red hover:bg-[#b72a2c]' : 'bg-[#c94a4c]'"
              >
                Enviar Pedido
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      studentId: "1",
      student: { email: '', enrolled: [] },
      form: {
        selectedCourseId: '',
        selectedNewShiftId: '',
      },
      jsonData: {
        students: [],
        courses: [],
        shifts: [],
        allocations: [],
        classrooms: [],
      },
      currentShift: null,
      availableShifts: [],
      loading: false,
      error: null,
    };
  },
  computed: {
    studentCourses() {
      const filteredCourses = this.jsonData.courses.filter(course => 
        this.student.enrolled.includes(Number(course.id))
      );
      console.log('Cursos filtrados:', filteredCourses);
      return filteredCourses;
    },
    formValid() {
      return this.form.selectedCourseId && this.form.selectedNewShiftId;
    },
  },
  methods: {
    async loadData() {
      this.loading = true;
      this.error = null;

      try {
        const [studentsRes, coursesRes, shiftsRes, allocationsRes, classroomsRes] = await Promise.all([
          axios.get('http://localhost:3000/students'),
          axios.get('http://localhost:3000/courses'),
          axios.get('http://localhost:3000/shifts'),
          axios.get('http://localhost:3000/allocations'),
          axios.get('http://localhost:3000/classrooms'),
        ]);

        this.jsonData.students = studentsRes.data;
        this.jsonData.courses = coursesRes.data;
        this.jsonData.shifts = shiftsRes.data;
        this.jsonData.allocations = allocationsRes.data;
        this.jsonData.classrooms = classroomsRes.data;

        console.log('Dados carregados - Alocações:', this.jsonData.allocations);
        console.log('Dados carregados - Turnos:', this.jsonData.shifts);

        const aluno = this.jsonData.students.find(s => Number(s.id) === Number(this.studentId));
        if (aluno) {
          this.student = {
            email: aluno.email,
            enrolled: aluno.enrolled || [],
          };
          console.log('Cursos inscritos:', this.student.enrolled);
        } else {
          console.error('Aluno não encontrado com ID:', this.studentId);
          this.error = 'Aluno não encontrado';
        }
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        this.error = 'Erro ao carregar dados do sistema. Verifique se o servidor JSON está rodando.';
      } finally {
        this.loading = false;
      }
    },

    loadCourseShifts() {
      console.log('Carregando turnos para o curso:', this.form.selectedCourseId);

      const courseId = Number(this.form.selectedCourseId);

      const alunoAllocations = this.jsonData.allocations
        .filter(a => Number(a.studentId) === Number(this.studentId))
        .map(a => Number(a.shiftId));

      console.log('Alocações do aluno (shiftIds):', alunoAllocations);

      const shiftsForCourse = this.jsonData.shifts
        .filter(shift => Number(shift.courseId) === courseId && alunoAllocations.includes(Number(shift.id)));

      console.log('Turnos inscritos do aluno para a UC:', shiftsForCourse);

      if (shiftsForCourse.length > 0) {
        this.currentShift = shiftsForCourse.map(shift => {
          const day = this.formatDay(shift.day);
          const from = shift.from;
          const to = shift.to;
          const classroom = this.getClassroomName(shift.classroomId);
          const occupation = this.calculateOccupation(shift);
          
          return `${shift.name}, ${day} ${from}:00-${to}:00, ${classroom}, ${occupation}%`;
        }).join('; ');
      } else {
        this.currentShift = null;
      }

      this.availableShifts = this.jsonData.shifts
        .filter(shift => {
          const isForCourse = Number(shift.courseId) === courseId;
          const notAllocated = !alunoAllocations.includes(Number(shift.id));
          const hasCapacity = shift.totalStudentsRegistered < this.getClassroomCapacity(shift.classroomId);
          console.log(`Turno ${shift.name}: isForCourse=${isForCourse}, notAllocated=${notAllocated}, hasCapacity=${hasCapacity}, totalStudents=${shift.totalStudentsRegistered}, capacity=${this.getClassroomCapacity(shift.classroomId)}`);
          return isForCourse && notAllocated && hasCapacity;
        })
        .map(shift => {
          const day = this.formatDay(shift.day);
          const from = shift.from;
          const to = shift.to;
          
          return {
            id: shift.id,
            name: `${shift.name}, ${day} ${from}:00-${to}:00`
          };
        });

      console.log('Turno atual:', this.currentShift);
      console.log('Turnos disponíveis:', this.availableShifts);
    },

    getClassroomName(id) {
      const classroom = this.jsonData.classrooms.find(c => Number(c.id) === Number(id));
      return classroom ? classroom.name : `Sala ${id}`;
    },

    getClassroomCapacity(id) {
      const classroom = this.jsonData.classrooms.find(c => Number(c.id) === Number(id));
      return classroom ? classroom.capacity : 0;
    },

    calculateOccupation(shift) {
      if (!shift.classroomId) return 0;
      
      const cap = this.getClassroomCapacity(shift.classroomId);
      if (cap === 0 || !shift.totalStudentsRegistered) return 0;
      
      return Math.round((shift.totalStudentsRegistered / cap) * 100);
    },

    formatDay(day) {
      const dias = {
        Monday: 'Segunda-Feira',
        Tuesday: 'Terça-Feira',
        Wednesday: 'Quarta-Feira',
        Thursday: 'Quinta-Feira',
        Friday: 'Sexta-Feira',
      };
      return dias[day] || day;
    },

    resetForm() {
      this.form = {
        selectedCourseId: '',
        selectedNewShiftId: '',
      };
      this.currentShift = null;
      this.availableShifts = [];
    },

    async submitForm() {
      if (!this.formValid) {
        alert('Por favor, preencha todos os campos obrigatórios');
        return;
      }

      const courseId = Number(this.form.selectedCourseId);
      const fromShiftId = this.jsonData.shifts.find(shift => 
        Number(shift.courseId) === courseId &&
        this.jsonData.allocations.some(a => 
          Number(a.shiftId) === Number(shift.id) && 
          Number(a.studentId) === Number(this.studentId)
        )
      )?.id || null;

      const novoPedido = {
        studentId: Number(this.studentId),
        shiftId: Number(this.form.selectedNewShiftId),
        fromShiftId: fromShiftId,
        reason: 'Mudança de turno',
        response: '',
        responseSeenByStudent: false,
      };

      console.log('Enviando pedido:', novoPedido);

      try {
        await axios.post('http://localhost:3000/shiftRequests', novoPedido);
        alert('Pedido enviado com sucesso!');
        this.resetForm();
      } catch (error) {
        console.error('Erro ao submeter pedido:', error);
        alert('Erro ao enviar pedido');
      }
    },
  },
  mounted() {
    this.loadData();
  },
};
</script>

<style scoped>
select {
  color: #333333;
}

select option {
  padding: 10px;
}

.bg-gray-100 {
  background-color: #f8f8f8;
}
.p-3.border.rounded-md.shadow-sm {
  min-height: 2.75rem;
}
</style>