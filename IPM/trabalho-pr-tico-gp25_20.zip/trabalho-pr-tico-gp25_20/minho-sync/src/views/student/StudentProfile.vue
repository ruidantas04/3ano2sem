<template>
  <div class="pt-[20px] px-[20px] pb-[20px]">
      <div class="mx-auto">
        <div class="flex justify-between items-center mb-6">
          <div class="flex items-center gap-4">
            <div class="w-16 h-16 rounded-full border-2 border-red-500 bg-white flex items-center justify-center">
              <span class="text-gray-500 font-medium">{{ studentInitials }}</span>
            </div>
            <h2 class="text-2xl font-bold">{{ student?.name || 'Nome do Estudante' }}</h2>
          </div>
          <router-link
            to="/unauthorized"
            class="bg-[#a21a1c] text-white px-4 py-2 rounded-full flex items-center gap-2"
          >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
            <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
          </svg>
            Editar Perfil
          </router-link>
        </div>
  
        <!-- Main Content -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="lg:col-span-2 bg-gray rounded-lg p-6 shadow-lg">
            <div class="bg-[#F6F6F6] rounded-lg p-5 mb-6 shadow-lg">
              <h3 class="text-xl font-bold mb-4">Informações Pessoais</h3>
  
              <div class="">
                <div>
                  <p class="text-[#868686] text-sm">Nome</p>
                  <p class="font-medium">{{ student?.name }}</p>
                </div>
  
                <div class="border-t border-gray pt-4">
                  <p class="text-[#868686] text-sm">Idade</p>
                  <p class="font-medium">{{ student?.age }} Anos</p>
                </div>
  
                <div class="border-t border-gray pt-4">
                  <p class="text-[#868686] text-sm">Localização</p>
                  <p class="font-medium">{{ student?.location  }}</p>
                </div>
  
                <div class="border-t border-gray pt-4">
                  <p class="text-[#868686] text-sm">Interesses</p>
                  <p class="font-medium">{{ student?.interests  }}</p>
                </div>
              </div>
            </div>
  
            <div class="bg-[#f0f0f0] rounded-lg p-5 mb-6 shadow-lg">
              <h3 class="text-xl font-bold mb-4">Objetivos e Desafios</h3>
              <div class="space-y-4">
                <div>
                  <p class="text-[#868686] text-sm">Objetivos</p>
                  <p class="font-medium">{{ student?.goals }}</p>
                </div>
  
                <div class="border-t border-gray pt-4">
                  <p class="text-[#868686] text-sm">Desafios</p>
                  <p class="font-medium">{{ student?.challenges  }}</p>
                </div>
  
                <div class="border-t border-gray pt-4">
                  <p class="text-[#868686] text-sm">Soluções</p>
                  <p class="font-medium">{{ student?.solutions }}</p>
                </div>
              </div>
            </div>
  
            <div class="bg-[#D1D1D1] rounded-lg p-4 italic text-sm">
              "{{ student?.comment }}" - {{ student?.name }}
            </div>
          </div>
  
          <div class="bg-gray rounded-lg p-6 shadow-sm">
            <h3 class="text-xl font-bold mb-4">Detalhes Académicos</h3>
  
            <div class="space-y-4">
              <div>
                <p class="text-[#868686] text-sm">Tipo</p>
                <p class="font-medium">{{ student?.courseType }}</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Ano Atual</p>
                <p class="font-medium">{{ student?.year}}º Ano</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Média Atual</p>
                <p class="font-medium">{{ student?.average  }} Valores</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Estatuto</p>
                <p class="font-medium">{{ student?.specialStatus === true ? 'Especial' : 'Regular' }}</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Aluno Mecanográfico</p>
                <p class="font-medium">{{ student?.mecanographicNumber }}</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Email</p>
                <p class="font-medium">{{ student?.email  }}</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">UCs Inscritas no Semestre</p>
                <p class="font-medium">{{ enrolledCourses.length }}</p>
              </div>
  
              <div class="border-t border-[#868686] pt-4">
                <p class="text-[#868686] text-sm">Horário Atual</p>
                <router-link
                :to="getScheduleRoute()"
                class="w-full bg-red text-white py-3 rounded-md mt-2 font-medium text-center block"
                >
                  Ver Horário
                </router-link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, computed, onMounted, watch } from 'vue';
  import axios from 'axios';
  import { useRoute, useRouter } from 'vue-router';
  
  const route = useRoute();
  const router = useRouter();

  const userType = ref('');
  const studentId = ref(null);
  const student = ref(null);
  const courses = ref([]);
  const loading = ref(true);
  const error = ref(null);
  
  // Determine which student profile to show based on user type
  
  // Get user type from localStorage
  const loggedInUserId = localStorage.getItem('userId');
  const storedUserType = localStorage.getItem('userType');
  
  // Use refs to hold the values
  const localStudentId = ref(null);
  const localUserType = ref(storedUserType);
  
  
  async function loadStudentData() {
    try {
      if (localUserType.value === 'student') {
        localStudentId.value = loggedInUserId;
  
        if (route.params.studentId && route.params.studentId !== loggedInUserId) {
          router.push(`/student/profile/${loggedInUserId}`);
          return;
        }
      } else if (['director', 'professor'].includes(localUserType.value)) {
        localStudentId.value = route.params.studentId;
      } else {
        router.push('/unauthorized');
        return;
      }
  
      if (localStudentId.value) {
        await fetchStudentData(localStudentId.value);
      }
    } catch (error) {
      console.error("Error loading student data:", error);
    }
  }
  
  onMounted(async () => {
    await loadStudentData();
  });
  
  // Add this watch function after onMounted
  watch(
    () => route.params.studentId,
    async () => {
      await loadStudentData();
    }
  );

  
  const studentInitials = computed(() => {
    return student.value?.name
      ? student.value.name
          .split(' ')
          .map(n => n[0])
          .join('')
          .toUpperCase()
      : '';
  });
  
  // Computed for enrolled courses
  const enrolledCourses = computed(() => {
    if (!student.value?.enrolled || !courses.value.length) return [];
    return courses.value
      .filter(course => student.value.enrolled.includes(parseInt(course.id)))
      .sort((a, b) => a.abbreviation.localeCompare(b.abbreviation));
  });

  const getScheduleRoute = () => {
    return localUserType.value === 'director' || localUserType.value === 'professor'
      ? `/director/student/${localStudentId.value}/schedule`
      : `/student/schedule`;
  };
  
  const fetchStudentData = async (studentId) => {
    loading.value = true;
    error.value = null;
  
    try {
      const [studentResponse, coursesResponse] = await Promise.all([
        axios.get(`http://localhost:3000/students/${studentId}`),
        axios.get('http://localhost:3000/courses'),
      ]);
  
      if (!studentResponse.data || !coursesResponse.data) {
        throw new Error('Invalid response data');
      }
  
      student.value = {
        ...studentResponse.data,
        ...(studentResponse.data.personalInfo || {}), 
      };
      
      courses.value = coursesResponse.data;
    } catch (err) {
      console.error('Error loading data:', err);
      error.value = getErrorMessage(err);
    } finally {
      loading.value = false;
    }
  };
  
  const getErrorMessage = (error) => {
    if (error.response) {
      switch (error.response.status) {
        case 404:
          return 'Estudante não encontrado';
        case 500:
          return 'Erro no servidor. Tente novamente mais tarde';
        default:
          return 'Erro ao carregar dados';
      }
    }
    return error.message || 'Não foi possível carregar os dados do estudante';
  };
  </script>
