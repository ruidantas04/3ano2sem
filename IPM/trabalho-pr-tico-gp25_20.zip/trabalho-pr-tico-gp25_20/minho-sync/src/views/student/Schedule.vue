<template>
    <div class="pt-[20px] px-[20px] pb-[0px]">
      <div class="flex flex-col lg:flex-row gap-6">
        <div class="w-full lg:w-[350px] bg-gray p-3 rounded-lg shadow-md overflow-hidden">
          <SeletorTurnosInscritos 
            :studentId="studentId" 
            @selection-change="handleSelectionChange" 
          />
        </div>
        
        <div class="flex-1">
          <div class="bg-gray rounded-lg shadow-md overflow-hidden">
            <div class="p-4">
              <Horario 
                :shiftIds="selectedShifts" 
                :showAll="false"
                @turno-click="handleTurnoClick"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
    
  <script setup>
  import { ref, onMounted } from 'vue';
  import Horario from '/src/components/Horario.vue';
  import SeletorTurnosInscritos from '/src/components/student/Seletor.vue';
  
  const studentId = ref('');
  const selectedShifts = ref([]);
  
  const handleTurnoClick = (turnoId) => {
    if (selectedShifts.value.includes(turnoId)) {
      selectedShifts.value = selectedShifts.value.filter(id => id !== turnoId);
    } 
    else {
      selectedShifts.value.push(turnoId);
    }
  };
  
  // Manipular mudanças na seleção do seletor
  const handleSelectionChange = (shifts) => {
    selectedShifts.value = shifts;
  };
  
  onMounted(() => {
    studentId.value = localStorage.getItem('userId') ; // Valor padrão para teste
  });
  </script>