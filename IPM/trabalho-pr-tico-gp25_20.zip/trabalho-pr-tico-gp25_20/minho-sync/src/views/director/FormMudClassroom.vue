<template>
  <div style="width: 893px; height: 848px; margin: 0 auto; margin-top:30px">
    <div class="text-white rounded-t-lg flex items-center min-h-[80px] px-4 relative" style="background-color: #A21A1C;">
      <div class="flex flex-col justify-center w-full text-center">
        <h2 class="text-[24px] font-semibold leading-tight">Pedido de Mudança de Sala</h2>
        <p class="text-[15px] mt-1 font-semibold">
          Solicitação recebida em {{ formatDate(pedido?.date) }} - 
          <span :class="{
            'text-yellow-300': pedido?.response === '' || pedido?.response === 'pending',
            'text-green-300': pedido?.response === 'ok',
            'text-red-300': pedido?.response === 'rejected'
          }">
            {{ mapStatus(pedido?.response) }}
          </span>
        </p>
      </div>
      <button @click="router.push('/director/requests')" 
              class="text-2xl font-bold absolute right-4 top-4">×</button>
    </div>
    <div class="bg-white rounded-b-lg shadow-lg p-10 space-y-4">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-black mb-1">Professor</label>
          <input type="text" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50"
            :value="teacher ? `${teacher.name} (${teacher.email})` : 'Não encontrado'" disabled />
        </div>
        <div>
          <label class="block text-sm font-bold text-black mb-1">Assunto</label>
          <input type="text" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50" value="Mudança de Sala" disabled />
        </div>
        <div>
          <label class="block text-sm font-bold text-black mb-1">Unidade Curricular</label>
          <input type="text" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50" :value="course?.name || '---'" disabled />
        </div>
        <div>
          <label class="block text-sm font-bold text-black mb-1">Turno</label>
          <input type="text" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50"
            :value="shift ? `${shift.name} (${formatHorario(shift)})` : '---'" disabled />
        </div>
        <div>
          <label class="block text-sm font-bold text-black mb-1">Sala Atual</label>
          <input type="text" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50"
            :value="classroom ? `${classroom.name} (Capacidade: ${classroom.capacity})` : '---'" disabled />
        </div>
        <div>
          <label class="block text-sm font-bold text-black mb-1">Motivo da Mudança</label>
          <textarea class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50" rows="3" :value="pedido?.reason" disabled></textarea>
        </div>
      </div>
      <div class="p-4 flex justify-end gap-3">
        <button @click="atualizarStatus('rejected')"
          class="border border-gray-400 text-gray-800 hover:bg-red-50 font-medium px-4 py-2 rounded-lg">
          Rejeitar Pedido
        </button>
        <button @click="atualizarStatus('ok')"
          class="text-white font-medium px-4 py-2 rounded-lg hover:bg-[#8B1618] transition-colors"
          style="background-color: #A21A1C;">
          Aprovar Pedido
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import axios from 'axios'
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const pedidoId = route.params.id

const pedido = ref(null)
const teacher = ref(null)
const shift = ref(null)
const classroom = ref(null)
const course = ref(null)

const mapStatus = (status) => {
  if (status === 'ok') return 'Aprovado'
  if (status === 'rejected') return 'Rejeitado'
  return 'Pendente'
}

const formatHorario = (turno) => {
  return `${turno.day} ${turno.from}h-${turno.to}h`
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  
  const date = new Date(dateString)
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

const fetchPedido = async () => {
  try {
    // Buscar o pedido de mudança de sala
    const res = await axios.get(`http://localhost:3000/classroomRequests/${pedidoId}`)
    if (!res.data) {
      throw new Error(`Pedido com ID ${pedidoId} não encontrado.`)
    }

    pedido.value = res.data

    // Buscar informações do professor
    const teacherRes = await axios.get(`http://localhost:3000/teachers/${pedido.value.teacherId}`)
    teacher.value = teacherRes.data

    // Buscar informações do turno
    const shiftRes = await axios.get(`http://localhost:3000/shifts/${pedido.value.shiftId}`)
    shift.value = shiftRes.data

    // Buscar informações da sala atual
    const classroomRes = await axios.get(`http://localhost:3000/classrooms/${pedido.value.classroomId}`)
    classroom.value = classroomRes.data

    // Buscar informações da unidade curricular
    if (shift.value?.courseId) {
      const courseRes = await axios.get(`http://localhost:3000/courses/${shift.value.courseId}`)
      course.value = courseRes.data
    }
  } catch (error) {
    console.error('Erro ao carregar pedido:', error)
  }
}

const atualizarStatus = async (novoStatus) => {
  try {
    await axios.patch(`http://localhost:3000/classroomRequests/${pedido.value.id}`, {
      response: novoStatus
    })
    if (pedido.value) {
        pedido.value.response = novoStatus
    }
    alert(`Pedido ${mapStatus(novoStatus)} com sucesso!`)
    router.push('/director/requests')
  } catch (err) {
    console.error('Erro ao atualizar o status do pedido:', err)
  }
}

onMounted(fetchPedido)
</script>