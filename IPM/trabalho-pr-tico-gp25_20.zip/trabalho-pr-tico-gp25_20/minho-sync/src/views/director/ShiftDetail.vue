<template>
    <div class="shift-detail-container">
      <div v-if="loading" class="flex justify-center items-center h-64">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-600"></div>
      </div>
      
      <div v-else>
        <!-- Cabeçalho da página -->
        <div class="p-6 rounded-lg">
          <div class="flex items-center justify-between mb-4">
            <div class="flex items-center">
              <div class="text-red-600 mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h1 class="text-2xl font-bold">{{ curso.nome }}</h1>
            </div>
            <button 
              @click="editarTurno" 
              class="bg-red-700 hover:bg-red-800 text-white py-2 px-4 rounded-md flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
              </svg>
              Editar Turno
            </button>
          </div>
    
          <!-- Informações do turno -->
          <div class="rounded-lg mb-6">
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 text-sm">
              <div>
                <span class="font-semibold">Turno:</span> {{ turno.nome }}
              </div>
              <div>
                <span class="font-semibold">Docente:</span> {{ turno.docente }} - {{ turno.docenteEmail }}
              </div>
              <div>
                <span class="font-semibold">Sala:</span> {{ turno.sala }}
              </div>
              <div>
                <span class="font-semibold">Horário:</span> {{ turno.horario }}
              </div>
              <div>
                <span class="font-semibold">Total de Alunos Inscritos:</span> {{ alunos.length }} alunos
              </div>
            </div>
          </div>
        </div>
  
        <!-- Tabela de alunos inscritos e notas -->
      <div class="bg-gray rounded-lg p-6">
        <div class="rounded-lg mb-6">
          <h2 class="text-xl font-bold mb-4">Alunos Inscritos</h2>

          <div class="overflow-x-auto">
            <table class="w-full">
              <thead>
                <tr class="border-b text-left text-red-600">
                  <th class="py-3 px-4">Aluno</th>
                  <th class="py-3 px-4">Nome</th>
                  <th class="py-3 px-4">Grupo do Trabalho Prático</th>
                  <th class="py-3 px-4">Estatuto</th>
                  <th class="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody>
                <tr 
                  v-for="aluno in alunos" 
                  :key="aluno.id" 
                  class="border-b hover:bg-gray-50 cursor-pointer transition-colors duration-150"
                  @click="verPerfilAluno(aluno.id)"
                >
                  <td class="py-4 px-4">{{ aluno.numero }}</td>
                  <td class="py-4 px-4 font-medium">{{ aluno.nome }}</td>
                  <td class="py-4 px-4">{{ aluno.grupo }}</td>
                  <td class="py-4 px-4">{{ aluno.estatuto }}</td>
                  <td class="py-4 px-4 text-center" @click.stop>
                    <div class="flex justify-center space-x-2">
                      <button 
                        class="text-gray-600 hover:text-red-600 transition-colors duration-150" 
                        @click.stop="editarAluno(aluno.id)"
                        title="Editar aluno"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/>
                        </svg>
                      </button>
                      <button 
                        class="text-gray-600 hover:text-red-600 transition-colors duration-150" 
                        @click.stop="removerAluno(aluno.id)"
                        title="Remover aluno"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
    
          <!-- Notas -->
          <div class="rounded-lg mb-6">
            <h2 class="text-xl font-bold mb-4">Notas:</h2>
            <div class="border rounded-lg p-4 bg-white mb-4">
              <textarea 
                v-model="turno.notas" 
                class="w-full  min-h-[100px] focus:outline-none resize-none"
                placeholder="Adicione notas sobre este turno..."
              ></textarea>
            </div>
            <div class="flex justify-between items-center">
              <p class="text-sm text-gray-500">Última atualização: {{ turno.ultimaAtualizacao }}</p>
              <button 
                @click="salvarNotas" 
                class="bg-red-700 hover:bg-red-800 text-white py-1 px-4 rounded-md text-sm"
              >
                Salvar Notas
              </button>
            </div>
          </div>
    
          <!-- Botão Voltar -->
          <button 
            @click="voltar" 
            class="bg-red-700 hover:bg-red-800 text-white py-2 px-6 rounded-md"
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import axios from 'axios';
  
  const route = useRoute();
  const router = useRouter();
  const shiftId = route.params.shiftId;
  
  const curso = ref({
    id: null,
    nome: '',
  });
  
  const turno = ref({
    id: null,
    nome: '',
    docente: '',
    docenteEmail: '',
    sala: '',
    horario: '',
    notas: '5 alunos querem mudar de turno',
    ultimaAtualizacao: '05/02/2023, 14:02:21'
  });
  
  const alunos = ref([]);
  const loading = ref(true);
  
  // Função para voltar à página anterior
  const voltar = () => {
    router.push(`/director/course/${curso.value.id}`);
  };
  
  // Função para editar o turno
  const editarTurno = () => {
    router.push(`/director/shift/${shiftId}/edit`);
  };

  // Função para ver perfil do aluno
const verPerfilAluno = (alunoId) => {
  router.push({ name: 'DirectorStudentProfile', params: { studentId: alunoId } });
};
  
  // Função para editar um aluno
  const editarAluno = (alunoId) => {
    // Implementar lógica para editar aluno
    console.log('Editar aluno:', alunoId);
  };
  
  // Função para remover um aluno
  const removerAluno = (alunoId) => {
    // Implementar lógica para remover aluno
    if (confirm('Tem certeza que deseja remover este aluno do turno?')) {
      console.log('Remover aluno:', alunoId);
      // Aqui você implementaria a chamada à API para remover o aluno
    }
  };
  
  // Função para salvar as notas
  const salvarNotas = async () => {
    try {
      // Atualizar a data de última atualização
      turno.value.ultimaAtualizacao = new Date().toLocaleString();
 
    } catch (error) {
      console.error('Erro ao salvar notas:', error);
      alert('Erro ao salvar notas. Por favor, tente novamente.');
    }
  };
  
  // Mapear dias da semana
  const mapDiaSemana = (dia) => {
    const diasMap = {
      'Monday': 'Segunda-feira',
      'Tuesday': 'Terça-feira',
      'Wednesday': 'Quarta-feira',
      'Thursday': 'Quinta-feira',
      'Friday': 'Sexta-feira'
    };
    return diasMap[dia] || dia;
  };
  
  // Buscar dados do turno
  const fetchShiftData = async () => {
    try {
      loading.value = true;
      
      // 1. Buscar dados do turno
      const shiftResponse = await axios.get(`http://localhost:3000/shifts/${shiftId}`);
      const shiftData = shiftResponse.data;
      
      // 2. Buscar dados do curso
      const courseResponse = await axios.get(`http://localhost:3000/courses/${shiftData.courseId}`);
      const courseData = courseResponse.data;
      
      // 3. Buscar dados do professor
      const teachersResponse = await axios.get('http://localhost:3000/teachers');
      const teachers = teachersResponse.data;
      const teacher = teachers.find(t => t.id == shiftData.teacherId);
      
      // 4. Buscar dados da sala
      const classroomsResponse = await axios.get('http://localhost:3000/classrooms');
      const classrooms = classroomsResponse.data;
      const classroom = classrooms.find(c => c.id == shiftData.classroomId);
      
      // 5. Buscar alocações (alunos inscritos neste turno)
      const allocationsResponse = await axios.get(`http://localhost:3000/allocations?shiftId=${shiftId}`);
      const allocations = allocationsResponse.data;
      
      // 6. Buscar dados dos alunos
      const studentsResponse = await axios.get('http://localhost:3000/students');
      const students = studentsResponse.data;
      
      // Atualizar dados do curso
      curso.value = {
        id: courseData.id,
        nome: courseData.name || 'Interface Pessoa-Máquina'
      };
      
      // Formatar o horário
      const diaSemana = mapDiaSemana(shiftData.day);
      const horario = `${diaSemana}, ${shiftData.from.toString().padStart(2, '0')}:00 - ${shiftData.to.toString().padStart(2, '0')}:00`;
      
      // Atualizar dados do turno
      turno.value = {
        id: shiftData.id,
        nome: shiftData.name ,
        docente: teacher?.name  ,
        docenteEmail: teacher?.email  ,
        sala: classroom.name,
        horario: horario,
        notas: '2 alunos querem mudar de turno',
        ultimaAtualizacao: new Date().toLocaleString()
      };
      
      // Processar dados dos alunos
      const alunosProcessados = allocations.map(allocation => {
        const student = students.find(s => s.id == allocation.studentId);
        return {
          id: student?.id || allocation.studentId,
          numero: student?.mecanographicNumber || `Aluno sem numero`,
          nome: student?.name || 'Aluno Sem Nome',
          grupo: allocation.group || `N/A`,
          estatuto: student?.specialStatus ? 'Especial' : 'Regular',
        };
      });
      
      alunos.value = alunosProcessados;
      loading.value = false;
    } catch (error) {
      console.error('Erro ao buscar dados do turno:', error);
      loading.value = false;
    
    }
  };
  
  // Carregar dados ao montar o componente
  onMounted(fetchShiftData);
  </script>
  
  <style scoped>
  .shift-detail-container {
    background-color: #f7fafc;
    min-height: 100vh;
    padding: 1.5rem;
  }
  
  /* Estilo para o textarea */
  textarea {
    font-family: inherit;
    line-height: 1.5;
    border: none;
  }
  
  textarea:focus {
    outline: none;
  }
  </style>