<template>
  <div class="pt-[20px] px-[20px] pb-[20px]">
    <div class="flex flex-col space-y-4">
      <div class="flex flex-row space-x-4">
        <div class="w-1/2 bg-gray-100 rounded-lg shadow-md px-4">
          <h2 class="text-xl font-bold py-4">Unidades Curriculares - {{ anoLabel }}</h2> 
          <div class="bg-red-800 rounded-t-lg overflow-hidden">
            
            <div class="py-3 px-4 text-center font-medium text-white">
              Unidades Curriculares do {{ anoLabel }}
            </div>
          </div>
          
          <!-- Lista de Unidades Curriculares -->
          <div class="border border-gray-300 rounded-b-lg overflow-hidden mb-6">
            <div v-for="(uc, index) in unidadesCurricularesFiltradas" :key="index" 
                class="py-3 px-4 border-b border-gray-300 hover:bg-gray-50 cursor-pointer"
                :class="ucSelecionada === uc.id ? 'bg-red-100' : ''"
                @click="selecionarUC(uc.id)">
              {{ uc.name }}
            </div>
            <div v-if="unidadesCurricularesFiltradas.length === 0" class="py-3 px-4 text-center text-gray-500">
              Não há unidades curriculares disponíveis para este ano.
            </div>
          </div>
          
          <!-- Gráfico de Alocações por UC -->
          <div class="p-4">
            <div class="h-64">
              <div class="flex h-full">
                <!-- Eixo Y com valores -->
                <div class="w-12 flex flex-col justify-between items-end pr-2">
                  <span class="text-sm text-gray-600">180</span>
                  <span class="text-sm text-gray-600">135</span>
                  <span class="text-sm text-gray-600">90</span>
                  <span class="text-sm text-gray-600">45</span>
                  <span class="text-sm text-gray-600">0</span>
                </div>
                
                <!-- Barras do gráfico - Modificado para alinhar na parte inferior -->
                <div class="flex-1 flex justify-around items-end">
                  <div v-for="(estatistica, index) in estatisticasPorUC" :key="index" class="flex flex-col items-center w-16">
                    <!-- Grupo de barras - Agora com altura fixa e items-end para alinhar na parte inferior -->
                    <div class="flex space-x-1 h-[200px] items-end">
                      <!-- Barra de Alocados -->
                      <div class="relative w-6 bg-red-900" :style="{ height: `${(estatistica.alocados / 180) * 200}px` }">
                        <!-- Rótulo com o número de alocados -->
                        <div class="absolute -top-6 w-full text-center text-xs font-semibold">
                          {{ estatistica.alocados }}
                        </div>
                      </div>
                      
                      <!-- Barra de Não Alocados -->
                      <div class="relative w-6 bg-red-500" :style="{ height: `${(estatistica.naoAlocados / 180) * 200}px` }">
                        <!-- Rótulo com o número de não alocados -->
                        <div class="absolute -top-6 w-full text-center text-xs font-semibold">
                          {{ estatistica.naoAlocados }}
                        </div>
                      </div>
                    </div>
                    
                    <!-- Rótulo da UC - Movido para baixo das barras -->
                    <div class="text-sm font-medium mt-2">{{ estatistica.abbreviation }}</div>
                  </div>
                </div>
              </div>
              
              <!-- Legenda -->
              <div class="flex justify-center mt-6">
                <div class="flex items-center mr-6">
                  <div class="w-4 h-4 bg-red-900 mr-2"></div>
                  <span class="text-sm">Alocados</span>
                </div>
                <div class="flex items-center">
                  <div class="w-4 h-4 bg-red-500 mr-2"></div>
                  <span class="text-sm">Não Alocados</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Coluna da direita: Alunos pendentes -->
        <div class="w-1/2 bg-gray-100 rounded-lg shadow-md px-4">
               <div class=" flex justify-between items-center">
          <h2 class="text-xl font-bold pt-4">Alunos pendentes de alocação</h2>
          <!-- Botão para limpar seleção de UC -->
          <button 
            v-if="ucSelecionada" 
            @click="limparSelecaoUC" 
            class="text-sm text-red-800 hover:text-red-600 flex items-center"
          >
            <span>Mostrar todos</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
               </div>
          <!-- Alerta -->
          <div class="p-4 bg-white border border-red-200 rounded-lg my-3 flex items-center">
            <div class="text-red-500 mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <span class="text-red-800">
              {{ alunosFiltradosPorUC.length }} Alunos precisam de alocação manual!
            </span>
          </div>
          
          <!-- Tabela de Alunos -->
          <div class="overflow-x-auto">
            <table class="w-full border-collapse">
              <thead>
                <tr class="bg-red-800 text-white">
                  <th class="py-3 px-4 text-left">Estudante</th>
                  <th class="py-3 px-4 text-left">Número</th>
                  <th class="py-3 px-4 text-left">Ano</th>
                  <th class="py-3 px-4 text-left">Estatuto</th>
                  <th class="py-3 px-4 text-left">UC Pendente</th>
                  <th class="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody>
                <tr 
                  v-for="(aluno, index) in alunosFiltradosPorUC" 
                  :key="index"
                  :class="index % 2 === 0 ? 'bg-white' : 'bg-gray-50'"
                  class="border-b border-gray-200"
                >
                  <td class="py-3 px-4">{{ aluno.name }}</td>
                  <td class="py-3 px-4">{{ aluno.number }}</td>
                  <td class="py-3 px-4">{{ getAnoLabel(aluno) }}</td>
                  <td class="py-3 px-4">{{ aluno.status }}</td>
                  <td class="py-3 px-4">
                    {{ ucSelecionada ? getCursoNome(ucSelecionada) : getUCsPendentesTexto(aluno) }}
                  </td>
                  <td class="py-3 px-4 text-center">
                    <button 
                      class="bg-red-800 hover:bg-red-700 text-white py-1 px-4 rounded-full text-sm transition-colors"
                      @click="alocarAluno(aluno)"
                    >
                      Alocar
                    </button>
                  </td>
                </tr>
                <tr v-if="alunosFiltradosPorUC.length === 0">
                  <td colspan="6" class="py-4 text-center text-gray-500">
                    Não há alunos pendentes de alocação 
                    <span v-if="ucSelecionada">para {{ getCursoNome(ucSelecionada) }}</span>
                    <span v-else>no {{ anoLabel }}</span>.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import axios from 'axios';
import { useRoute, useRouter } from 'vue-router';

// Obter parâmetros da rota
const route = useRoute();
const router = useRouter();

// Extrair o ano da rota - este é o ano específico que queremos mostrar
const anoFiltro = ref(parseInt(route.params.ano) || 1); // Default para 1 se não especificado

// Formatar o ano como label
const anoLabel = computed(() => {
  return `${anoFiltro.value}º Ano`;
});

// URLs do JSON Server
const STUDENTS_URL = `http://localhost:3000/students`;
const ALLOCATIONS_URL = `http://localhost:3000/allocations`;
const SHIFTS_URL = `http://localhost:3000/shifts`;
const COURSES_URL = `http://localhost:3000/courses`;

// Estado
const alunos = ref([]);
const alocacoes = ref([]);
const turnos = ref([]);
const cursos = ref([]);
const loading = ref(true);
const error = ref(null);
const ucSelecionada = ref(null); // Inicialmente nenhuma UC selecionada

// Buscar dados
const fetchData = async () => {
  try {
    loading.value = true;
    
    // Buscar alunos
    const studentsResponse = await axios.get(STUDENTS_URL);
    alunos.value = studentsResponse.data;
    
    // Buscar alocações
    const allocationsResponse = await axios.get(ALLOCATIONS_URL);
    alocacoes.value = allocationsResponse.data;
    
    // Buscar turnos
    const shiftsResponse = await axios.get(SHIFTS_URL);
    turnos.value = shiftsResponse.data;
    
    // Buscar cursos
    const coursesResponse = await axios.get(COURSES_URL);
    cursos.value = coursesResponse.data;
    
    console.log(`Carregando dados para o ${anoLabel.value}`);
    console.log(`Total de cursos: ${cursos.value.length}`);
    console.log(`Cursos do ${anoLabel.value}: ${unidadesCurricularesFiltradas.value.length}`);
    
    // Não selecionar nenhuma UC inicialmente
    ucSelecionada.value = null;
    
    loading.value = false;
  } catch (err) {
    console.error('Erro ao buscar dados:', err);
    error.value = 'Erro ao carregar dados. Por favor, tente novamente.';
    loading.value = false;
  }
};

// Computed property para filtrar UCs APENAS pelo ano da rota
const unidadesCurricularesFiltradas = computed(() => {
  // Filtrar apenas as UCs do ano específico da rota
  return cursos.value.filter(curso => curso.year === anoFiltro.value);
});

// Função para verificar se um aluno está alocado em uma UC específica
const alunoEstaAlocadoEmUC = (alunoId, cursoId) => {
  // Garantir que estamos trabalhando com números para comparação
  const alunoIdNum = Number(alunoId);
  const cursoIdNum = Number(cursoId);
  
  // Obter todos os turnos desta UC
  const turnosDaUC = turnos.value.filter(turno => Number(turno.courseId) === cursoIdNum);
  
  if (turnosDaUC.length === 0) {
    return false;
  }
  
  const turnosIds = turnosDaUC.map(turno => Number(turno.id));
  
  // Verificar se o aluno tem alguma alocação em qualquer turno desta UC
  const alocacoesDoAluno = alocacoes.value.filter(alocacao => Number(alocacao.studentId) === alunoIdNum);
  
  // Verificar se alguma das alocações do aluno corresponde a um dos turnos da UC
  const estaAlocado = alocacoesDoAluno.some(alocacao => 
    turnosIds.includes(Number(alocacao.shiftId))
  );
  
  return estaAlocado;
};

// Computed property para obter estatísticas de alocação por UC (apenas do ano filtrado)
const estatisticasPorUC = computed(() => {
  const resultado = [];
  
  unidadesCurricularesFiltradas.value.forEach(curso => {
    // Contar alunos inscritos nesta UC
    const alunosInscritos = alunos.value.filter(aluno =>
      aluno.enrolled && aluno.enrolled.includes(Number(curso.id))
    );
    
    // Contar alunos alocados nesta UC
    const alunosAlocados = alunosInscritos.filter(aluno =>
      alunoEstaAlocadoEmUC(aluno.id, curso.id)
    );
    
    resultado.push({
      id: curso.id,
      name: curso.name,
      abbreviation: curso.abbreviation,
      totalInscritos: alunosInscritos.length,
      alocados: alunosAlocados.length,
      naoAlocados: alunosInscritos.length - alunosAlocados.length
    });
  });
  
  return resultado;
});

// Computed property para obter alunos pendentes de alocação para a UC selecionada
const alunosFiltradosPorUC = computed(() => {
  // Obter IDs de todas as UCs do ano filtrado
  const idsUCsDoAno = unidadesCurricularesFiltradas.value.map(uc => Number(uc.id));
  
  if (!ucSelecionada.value) {
    // Se nenhuma UC estiver selecionada, retornar todos os alunos pendentes do ano específico
    return alunos.value
      .filter(aluno => {
        if (!aluno.enrolled) return false;
        
        // Verificar se o aluno está inscrito em alguma UC do ano filtrado
        const ucsDoAnoInscritas = aluno.enrolled.filter(cursoId => 
          idsUCsDoAno.includes(Number(cursoId))
        );
        
        // Verificar se o aluno não está alocado em alguma dessas UCs
        return ucsDoAnoInscritas.some(cursoId => !alunoEstaAlocadoEmUC(aluno.id, cursoId));
      })
      .map(aluno => {
        // Extrair número do aluno do email
        const match = aluno.email.match(/^[a-z]?(\d+)@/);
        const number = match ? match[1] : 'N/A';
        
        // Determinar status do aluno
        const status = aluno.specialStatus ? 'Especial' : 'Regular';
        
        return {
          ...aluno,
          number,
          status,
          // Filtrar apenas as UCs pendentes do ano específico
          ucsPendentes: aluno.enrolled
            .filter(cursoId => 
              idsUCsDoAno.includes(Number(cursoId)) && 
              !alunoEstaAlocadoEmUC(aluno.id, cursoId)
            )
        };
      });
  } else {
    // Se uma UC estiver selecionada, filtrar apenas os alunos pendentes para essa UC
    return alunos.value
      .filter(aluno => {
        if (!aluno.enrolled) return false;
        
        // Verificar se o aluno está inscrito na UC selecionada
        return aluno.enrolled.includes(Number(ucSelecionada.value)) && 
               !alunoEstaAlocadoEmUC(aluno.id, ucSelecionada.value);
      })
      .map(aluno => {
        // Extrair número do aluno do email
        const match = aluno.email.match(/^[a-z]?(\d+)@/);
        const number = match ? match[1] : 'N/A';
        
        // Determinar status do aluno
        const status = aluno.specialStatus ? 'Especial' : 'Regular';
        
        return {
          ...aluno,
          number,
          status,
          ucsPendentes: [Number(ucSelecionada.value)]
        };
      });
  }
});

// Função para selecionar uma UC
const selecionarUC = (ucId) => {
  ucSelecionada.value = ucId;
  console.log(`UC selecionada: ${getCursoNome(ucId)} (ID: ${ucId})`);
  console.log(`Alunos pendentes para esta UC: ${alunosFiltradosPorUC.value.length}`);
};

// Função para limpar a seleção de UC
const limparSelecaoUC = () => {
  ucSelecionada.value = null;
  console.log(`Seleção de UC limpa. Mostrando todos os alunos pendentes do ${anoLabel.value}`);
};

// Função para obter o nome de um curso pelo ID
const getCursoNome = (cursoId) => {
  const curso = cursos.value.find(c => Number(c.id) === Number(cursoId));
  return curso ? curso.name : 'N/A';
};

// Função para obter o ano de um aluno (baseado nas UCs em que está inscrito)
const getAnoLabel = (aluno) => {
  // Para esta página específica, sempre mostrar o ano da rota
  return anoLabel.value;
};

// Função para obter texto das UCs pendentes de um aluno (apenas do ano filtrado)
const getUCsPendentesTexto = (aluno) => {
  if (!aluno.ucsPendentes || aluno.ucsPendentes.length === 0) return 'N/A';
  
  return aluno.ucsPendentes
    .map(cursoId => {
      const curso = cursos.value.find(c => Number(c.id) === Number(cursoId));
      return curso ? curso.abbreviation : null;
    })
    .filter(abbr => abbr !== null)
    .join(', ');
};

// Função para alocar um aluno
const alocarAluno = (aluno) => {
  router.push(`/director/student/${aluno.id}`);
};

// Observar mudanças na rota para atualizar o filtro de ano
watch(() => route.params.ano, (novoAno) => {
  anoFiltro.value = parseInt(novoAno) || 1; // Default para 1 se não especificado
  
  // Resetar a UC selecionada quando o ano mudar
  ucSelecionada.value = null;
  
  console.log(`Ano alterado para: ${anoFiltro.value}`);
});

// Carregar dados ao montar o componente
onMounted(fetchData);
</script>
