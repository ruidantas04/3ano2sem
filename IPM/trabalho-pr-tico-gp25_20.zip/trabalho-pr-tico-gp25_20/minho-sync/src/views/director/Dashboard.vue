<template>
  <div class=" p-6">
    <div v-if="loading" class="flex justify-center items-center h-64">
      <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-600"></div>
    </div>
    
    <div v-else>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-gray rounded-lg shadow-md p-6">
          <h3 class="text-lg font-bold mb-3">Alunos com turnos por Alocar</h3>
          <p class="text-4xl font-bold text-yellow-500 text-center">{{ estatisticas.alunosPorAlocar }}</p>
        </div>
        
        <div class="bg-gray rounded-lg shadow-md p-6">
          <h3 class="text-lg font-bold mb-3">Alunos com Conflitos</h3>
          <p class="text-4xl font-bold text-red-600 text-center">{{ estatisticas.alunosComConflitos }}</p>
        </div>
        
        <div class="bg-gray rounded-lg shadow-md p-6">
          <h3 class="text-lg font-bold mb-3">Alunos Alocados</h3>
          <p class="text-4xl font-bold text-center">{{ estatisticas.alunosAlocados }}/{{ estatisticas.totalAlunos }}</p>
        </div>
      </div>
      
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-gray rounded-lg shadow-md">
          <div class="flex justify-between items-center p-4">
            <h2 class="text-xl font-bold">Ocupação dos Turnos</h2>
            <div class="relative">
              <select 
                v-model="selectedSemester" 
                @change="filtrarCursosPorSemestre"
                class="bg-gray-200 rounded-md px-3 py-1 pr-8 appearance-none"
              >
                <option value="all">2024/2025</option>
                <option value="1">2024/2025 - S1</option>
                <option value="2">2024/2025 - S2</option>
              </select>
              <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </div>
            </div>
          </div>
          
          <div class="overflow-x-auto max-h-[615px] overflow-y-auto">
            <table class="w-full">
              <thead class="sticky top-0 z-10">
                <tr class="bg-gray text-red">
                  <th class="py-3 px-4 text-left">Unidade Curricular</th>
                  <th class="py-3 px-4 text-left">Ano Letivo</th>
                  <th class="py-3 px-4 text-left">Docente Regente</th>
                  <th class="py-3 px-4 text-left">Alunos Inscritos Alocados</th>
                  <th class="py-3 px-4 text-right"></th>
                </tr>
              </thead>
              <tbody>
                <tr 
                  v-for="curso in cursosFiltrados" 
                  :key="curso.id" 
                  class="border-t border-gray-300 hover:bg-gray-50 cursor-pointer"
                  @click="navegarParaCurso(curso.id)"
                >
                  <td class="py-3 px-4">{{ curso.nome }}</td>
                  <td class="py-3 px-4">{{ curso.anoSemestre }}</td>
                  <td class="py-3 px-4">{{ curso.professor }}</td>
                  <td class="py-3 px-4 w-1/4">
                    <div class="flex items-center justify-center">
                      <div class="w-full bg-white rounded-full p-1.5 shadow-sm">
                        <div class="bg-gray-100 rounded-full w-full">
                          <div 
                            class="h-3 rounded-full transition-all duration-300 ease-in-out" 
                            :class="getProgressBarColor(curso.percentagem)"
                            :style="{ width: `${curso.percentagem}%` }"
                          ></div>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap">
                    {{ curso.percentagem }}% {{ curso.alunosAlocados }}/{{ curso.capacidadeTotal }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="lg:col-span-1 space-y-6">
          <div class="bg-gray rounded-lg shadow-md h-[300px]">
            <div class="flex items-center justify-between p-4 px-7">
              <h2 class="text-xl font-bold flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-red" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                Notificações
              </h2>
              <span class="bg-red-600 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center">
                {{ notificacoes.length }}
              </span>
            </div>
            
            <div class="px-7 max-h-[240px] overflow-y-auto">
              <div 
                v-for="notificacao in notificacoes" 
                :key="notificacao.id" 
                class="p-3 border border-dark-red bg-red-100 rounded-lg mb-2 hover:bg-red-200 cursor-pointer"
                @click="navegarParaNotificacao(notificacao)"
              >
                <div class="flex justify-between items-start">
                  <div>
                    <p class="font-medium">{{ notificacao.mensagem }}</p>
                    <p v-if="notificacao.motivo" class="text-sm text-gray-500">Motivo: {{ notificacao.motivo }}</p>
                    <p class="text-sm text-gray-600">Pedido por: {{ notificacao.solicitante }}</p>
                    <p class="text-xs text-gray-400 mt-1">{{ notificacao.data }}</p>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
              
              <div v-if="notificacoes.length === 0" class="p-3 text-center text-gray-500">
                Não há notificações no momento.
              </div>
            </div>
          </div>
          
          <div class="bg-gray rounded-lg shadow-md">
            <div class="p-4">
              <h2 class="text-xl font-bold flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="h-5 w-5 mr-2 text-red" viewBox="0 0 16 16">
                  <path d="M3 14.5A1.5 1.5 0 0 1 1.5 13V3A1.5 1.5 0 0 1 3 1.5h8a.5.5 0 0 1 0 1H3a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h10a.5.5 0 0 0 .5-.5V8a.5.5 0 0 1 1 0v5a1.5 1.5 0 0 1-1.5 1.5z"/>
                  <path d="m8.354 10.354 7-7a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0"/>
                </svg>
                Atalhos
              </h2>
            </div>
            
            <div class="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="border border-dark-red rounded-4xl p-4 bg-red-100 hover:bg-red-200 cursor-pointer" @click="navegarParaAlocarManualmente();">
                <div class="flex items-center">
                  <div class="p-2 mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                  </div>
                  <div>
                    <h3 class="font-bold text-sm">Alocar Manualmente</h3>
                  </div>
                </div>
                <p class="text-xs p-2 text-gray-600">Faltam {{ estatisticas.alunosPorAlocar }} alunos para serem alocados ou com conflitos.</p>
              </div>
              
              <div class="border border-dark-red rounded-4xl p-4 bg-red-100 hover:bg-red-200 cursor-pointer" @click="navegarPedidos();">
                  <div class="flex items-center">
                    <div class="rounded-full p-2">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    </div>
                    <div>
                      <h3 class="font-bold text">Ver Pedidos Pendentes</h3>
                    </div>
                  </div>
                  <p class="text-xs p-2 text-gray-600">Existem {{ pedidosPendentes }} pedidos pendentes.</p>
              </div>
              
              <div class="border border-dark-red rounded-4xl p-4 bg-red-100 hover:bg-red-200 cursor-pointer" @click="publicarHorarios();">
                  <div class="flex items-center">
                    <div class="rounded-full p-2">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 class="font-bold text">Publicar Horários</h3>
                    </div>
                  </div>
                    <p class="text-xs p-2 text-gray-600">Os alunos ainda não têm o seu horário publicado.</p>
              </div>
              
              <div class="border border-dark-red rounded-4xl p-4 bg-red-100 hover:bg-red-200 cursor-pointer" @click="navegarParaHorarioGeral();">
                <div class="flex items-center">
                  <div class="rounded-full p-2 mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <div>
                    <h3 class="font-bold text-sm">Ver Horário Geral e Capacidades</h3>
                  </div>
                </div>
                <p class="text-xs p-2 text-gray-600">Veja agora os horários e disponibilidades.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, onUnmounted } from "vue";
import { useRouter } from "vue-router";
import axios from "axios";

const router = useRouter();
const loading = ref(true);
const students = ref([]);
const shifts = ref([]);
const courses = ref([]);
const teachers = ref([]);
const classrooms = ref([]);
const allocations = ref([]);
const conflicts = ref([]);
const shiftRequests = ref([]);
const classroomRequests = ref([]);
const selectedSemester = ref("all");

// Estatísticas
const estatisticas = ref({
  alunosPorAlocar: 0,
  alunosComConflitos: 0,
  alunosAlocados: 0,
  totalAlunos: 0,
});

// Cursos com ocupação
const cursos = ref([]);
const cursosFiltrados = ref([]);

// Notificações
const notificacoes = ref([]);

// Pedidos pendentes
const pedidosPendentes = computed(() => {
  return (
    shiftRequests.value.filter((req) => req.response === "").length +
    classroomRequests.value.filter((req) => req.response === "").length
  );
});

const navegarParaAlocarManualmente = () => {
  router.push('/director/manual-allocation')
}

const navegarPedidos = () => {
  router.push('/director/requests')
}

const publicarHorarios = () => {
  alert("Publicados");
}

const navegarParaHorarioGeral = () => {
  router.push('/director/schedule')
}

const navegarParaCurso = (cursoId) => {
  router.push(`/director/course/${cursoId}`);
};

// Navegar para a página de notificação específica
const navegarParaNotificacao = (notificacao) => {
    router.push(`/director/requests/${notificacao.tipo}/${notificacao.requestId}`);
};

// Funções auxiliares para obter nomes a partir de IDs
const getStudentName = (studentId) => {
  const student = students.value.find(s => s.id == studentId);
  return student ? student.name : `Aluno ${studentId}`;
};

const getTeacherName = (teacherId) => {
  const teacher = teachers.value.find(t => t.id == teacherId);
  return teacher ? teacher.name : `Professor ${teacherId}`;
};


const getCourseInfo = (shiftId) => {
  const shift = shifts.value.find(s => s.id == shiftId);
  if (!shift) return `Não encontrado`;
  
  const course = courses.value.find(c => c.id == shift.courseId);
  const courseName = course ? course.abbreviation || course.name : `Não encontrado`;
  
  return `${courseName}`;
};

const getShiftInfo = (shiftId) => {
  const shift = shifts.value.find(s => s.id == shiftId);
  if (!shift) return `Turno ${shiftId}`;
  
  const course = courses.value.find(c => c.id == shift.courseId);
  const courseName = course ? course.abbreviation || course.name : `Curso ${shift.courseId}`;
  
  return `${courseName} - Turno ${shift.name || shift.id}`;
};

const getClassroomName = (classroomId) => {
  const classroom = classrooms.value.find(c => c.id == classroomId);
  return classroom ? classroom.name : `Sala ${classroomId}`;
};

// Filtrar cursos por semestre
const filtrarCursosPorSemestre = () => {
  if (selectedSemester.value === "all") {
    cursosFiltrados.value = [...cursos.value];
  } else {
    const semestre = parseInt(selectedSemester.value);
    cursosFiltrados.value = cursos.value.filter(curso => {
      // Extrair o semestre do formato "X Ano, Y Semestre"
      const semestreMatch = curso.anoSemestre.match(/(\d+) Semestre/);
      if (semestreMatch && semestreMatch[1]) {
        return parseInt(semestreMatch[1]) === semestre;
      }
      return false;
    });
  }
};

// Buscar dados
const fetchData = async () => {
  try {
    loading.value = true;

    // Buscar todos os dados necessários
    const [
      studentsRes,
      shiftsRes,
      coursesRes,
      teachersRes,
      classroomsRes,
      allocationsRes,
      conflictsRes,
      shiftRequestsRes,
      classroomRequestsRes,
    ] = await Promise.all([
      axios.get("http://localhost:3000/students"),
      axios.get("http://localhost:3000/shifts"),
      axios.get("http://localhost:3000/courses"),
      axios.get("http://localhost:3000/teachers"),
      axios.get("http://localhost:3000/classrooms"),
      axios.get("http://localhost:3000/allocations"),
      axios.get("http://localhost:3000/conflicts"),
      axios.get("http://localhost:3000/shiftRequests"),
      axios.get("http://localhost:3000/classroomRequests"),
    ]);

    students.value = studentsRes.data;
    shifts.value = shiftsRes.data;
    courses.value = coursesRes.data;
    teachers.value = teachersRes.data;
    classrooms.value = classroomsRes.data;
    allocations.value = allocationsRes.data;
    conflicts.value = conflictsRes.data;
    shiftRequests.value = shiftRequestsRes.data;
    classroomRequests.value = classroomRequestsRes.data;

    // Calcular estatísticas
    calcularEstatisticas();

    // Preparar dados dos cursos
    prepararDadosCursos();

    // Preparar notificações
    prepararNotificacoes();

    // Inicializar cursos filtrados com todos os cursos
    cursosFiltrados.value = [...cursos.value];

    loading.value = false;
  } catch (error) {
    console.error("Erro ao buscar dados:", error);
    loading.value = false;
  }
};

// Calcular estatísticas
const calcularEstatisticas = () => {
  // Total de alunos
  estatisticas.value.totalAlunos = students.value.length;

  // Alunos com conflitos
  estatisticas.value.alunosComConflitos = conflicts.value.length;

  // Alunos alocados (alunos que têm pelo menos uma alocação)
  const alunosComAlocacao = new Set(allocations.value.map((a) => a.studentId));
  estatisticas.value.alunosAlocados = alunosComAlocacao.size;

  // Alunos por alocar (alunos sem alocação ou com conflitos)
  estatisticas.value.alunosPorAlocar =
    estatisticas.value.totalAlunos - estatisticas.value.alunosAlocados + estatisticas.value.alunosComConflitos;
};

// Preparar dados dos cursos para a tabela de ocupação
const prepararDadosCursos = () => {
  // Criar um mapa de professores para fácil acesso
  const professoresMap = teachers.value.reduce((acc, teacher) => {
    acc[teacher.id] = teacher.name;
    return acc;
  }, {});

  // Criar um mapa de salas para fácil acesso
  const salasMap = classrooms.value.reduce((acc, classroom) => {
    acc[classroom.id] = classroom.capacity;
    return acc;
  }, {});

  // Agrupar turnos por curso
  const turnosPorCurso = {};
  shifts.value.forEach((shift) => {
    if (!turnosPorCurso[shift.courseId]) {
      turnosPorCurso[shift.courseId] = [];
    }
    turnosPorCurso[shift.courseId].push(shift);
  });

  // Contar alocações por turno
  const alocacoesPorTurno = {};
  allocations.value.forEach((allocation) => {
    if (!alocacoesPorTurno[allocation.shiftId]) {
      alocacoesPorTurno[allocation.shiftId] = 0;
    }
    alocacoesPorTurno[allocation.shiftId]++;
  });

  // Preparar dados dos cursos
  cursos.value = courses.value.map((course) => {
    const turnosDoCurso = turnosPorCurso[course.id] || [];

    // Calcular total de alunos alocados neste curso
    let totalAlunosAlocados = 0;
    let capacidadeTotal = 0;

    turnosDoCurso.forEach((turno) => {
      const alunosNoTurno = alocacoesPorTurno[turno.id] || 0;
      totalAlunosAlocados += alunosNoTurno;

      // Adicionar capacidade da sala
      const capacidadeSala = salasMap[turno.classroomId] || 30;
      capacidadeTotal += capacidadeSala;
    });

    // Calcular percentagem de ocupação
    const percentagem = capacidadeTotal > 0 ? Math.round((totalAlunosAlocados / capacidadeTotal) * 100) : 0;

    return {
      id: course.id,
      nome: course.name,
      anoSemestre: `${course.year} Ano, ${course.semester} Semestre`,
      professor: professoresMap[turnosDoCurso[0]?.teacherId] || "Prof. NOME DO DOCENTE",
      alunosAlocados: totalAlunosAlocados,
      capacidadeTotal: capacidadeTotal,
      percentagem: percentagem,
      semester: course.semester // Adicionado para facilitar a filtragem
    };
  });
};

// Preparar notificações com nomes em vez de IDs
const prepararNotificacoes = () => {
  // Limpar notificações existentes
  notificacoes.value = [];
  
  // Filtrar pedidos de sala pendentes (response vazio ou diferente de "ok" e "rejected")
  const pedidosSalaPendentes = classroomRequests.value.filter(req => 
    req.response === "" || (req.response !== "ok" && req.response !== "rejected")
  );
  
  // Filtrar pedidos de turno pendentes (response vazio ou diferente de "ok" e "rejected")
  const pedidosTurnoPendentes = shiftRequests.value.filter(req => 
    req.response === "" || (req.response !== "ok" && req.response !== "rejected")
  );
  
  // Adicionar notificações de pedidos de sala
  pedidosSalaPendentes.forEach(request => {
    // Obter nomes em vez de IDs
    const professorName = getTeacherName(request.teacherId);
    const shiftInfo = getShiftInfo(request.shiftId);
    const currentClassroom = getClassroomName(request.currentClassroomId);
    const courseName = getCourseInfo(request.shiftId);
    
    notificacoes.value.push({
      id: `${request.id}`,
      tipo: 'classroom',
      mensagem: `Mudar ${shiftInfo} para sala diferente - ${courseName}`,
      solicitante: professorName,
      motivo: request.reason,
      data: request.date,
      requestId: request.id
    });
  });
  
  // Adicionar notificações de pedidos de turno
  pedidosTurnoPendentes.forEach(request => {
    // Obter nomes em vez de IDs
    const studentName = getStudentName(request.studentId);
    const fromShiftInfo = getShiftInfo(request.fromShiftId);
    const toShiftInfo = getShiftInfo(request.shiftId);
    const courseName = getCourseInfo(request.fromShiftId);
    
    notificacoes.value.push({
      id: `${request.id}`,
      tipo: 'shift',
      mensagem: `Mudar turno de ${fromShiftInfo} para ${toShiftInfo} - ${courseName}`,
      solicitante: studentName,
      motivo: request.reason,
      data: request.date,
      requestId: request.id
    });
  });
};

// Obter cor da barra de progresso com base na porcentagem
const getProgressBarColor = (percentagem) => {
  if (percentagem >= 75) return "bg-red-500";
  if (percentagem >= 45) return "bg-yellow-500";
  return "bg-green-500";
};

// Carregar dados ao montar o componente
onMounted(() => {
  fetchData();
  
  // Configurar intervalo para atualizar os dados a cada 30 segundos
  const interval = setInterval(fetchData, 30000);
  
  // Limpar intervalo quando o componente for desmontado
  onUnmounted(() => {
    clearInterval(interval);
  });
});
</script>

<style scoped>
/* Estilo para as barras de progresso */
.progress-bar {
  height: 10px;
  border-radius: 5px;
  transition: width 0.5s ease-in-out;
}

/* Estilo para a tabela com altura fixa */
thead {
  background-color: #f7fafc;
}

/* Estilo para o hover nas linhas da tabela */
tbody tr:hover {
  background-color: rgba(0, 0, 0, 0.05);
}
</style>