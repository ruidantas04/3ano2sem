<template>
    <div class="pt-[20px] px-[20px] pb-[0px]">
      <div class="flex flex-col lg:flex-row gap-3">
        <!-- Barra lateral com ícones -->
        <div class="w-full lg:w-[50px] p-2 bg-gray rounded-lg shadow-md overflow-hidden">
          <div class="flex flex-row lg:flex-col gap-2 justify-center items-center">
            <!-- Ícone para seletor de turnos -->
            <div class="flex justify-center justify-center items-center cursor-pointer transition-colors w-10 h-10 rounded-lg "
            :class="activeTab === 'seletor' ? 'bg-red text-white shadow-md' : 'bg-white text-red hover:bg-gray'"
              @click="activeTab = 'seletor'"
            >
              <div class="flex justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
            </div>
            
            <!-- Ícone para ocupação -->
            <div 
              class="flex-1"

            >
              <div class="flex justify-center justify-center items-center cursor-pointer transition-colors w-10 h-10 rounded-lg"
                :class="activeTab === 'ocupacao' ? 'bg-red text-white shadow-md' : 'bg-white text-red hover:bg-gray'"
                @click="activeTab = 'ocupacao'">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Painel lateral (seletor ou ocupação) -->
        <div class="w-full lg:w-[350px] bg-gray p-2 rounded-lg shadow-md overflow-hidden">
          <!-- Seletor de turnos -->
          <SeletorTurnos 
            v-if="activeTab === 'seletor'"
            :initialSelection="selectedShifts" 
            @selection-change="handleSelectionChange" 
          />
          
          <!-- Componente de ocupação -->
          <OcupacaoTurnos 
            v-else-if="activeTab === 'ocupacao'"
            :shiftIds="selectedShifts"
            @selection-change="handleSelectionChange"
          />
        </div>
        
        <!-- Horário -->
        <div class="flex-1">
          <div class="bg-white rounded-lg shadow-md overflow-hidden">
   
            <div class="bg-gray p-4">
              <Horario 
                :shiftIds="selectedShifts" 
                :showAll="selectedShifts.length === 0"
                @turno-click="handleTurnoClick"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref} from 'vue';
  import Horario from '/src/components/Horario.vue';
  import SeletorTurnos from '/src/components/Seletor.vue';
  import OcupacaoTurnos from '/src/components/director/OcupacaoTurnos.vue';
  
  const activeTab = ref('seletor');
  const selectedShifts = ref([]);
  
  // Manipular clique em um turno no horário
  const handleTurnoClick = (turnoId) => {
    // Se o turno já está selecionado, remova-o
    if (selectedShifts.value.includes(turnoId)) {
      selectedShifts.value = selectedShifts.value.filter(id => id !== turnoId);
    } 
    // Caso contrário, adicione-o
    else {
      selectedShifts.value.push(turnoId);
    }
  };
  
  // Manipular mudanças na seleção do seletor
  const handleSelectionChange = (shifts) => {
    console.log("Seleção alterada:", shifts);
    selectedShifts.value = [...shifts];
  };

  </script>