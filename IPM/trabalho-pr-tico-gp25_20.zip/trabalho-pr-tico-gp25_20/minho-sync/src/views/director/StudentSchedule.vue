<template>
  <div class="pt-[20px] px-[20px] pb-[0px]">
    <div class="flex flex-col lg:flex-row gap-6">
      <div class="w-full lg:w-[350px] bg-gray p-3 rounded-lg shadow-md overflow-hidden">
        <SeletorTurnosInscritos 
          :studentId="studentId" 
          :initialSelection="selectedShifts"
          @selection-change="handleSelectionChange" 
        />
      </div>
      
      <div class="flex-1">
        <div class="bg-gray rounded-lg shadow-md overflow-hidden">
          <div class="p-4">
            <Horario 
              :shiftIds="selectedShifts" 
              :showAll="false"
              @turno-click="handleTurnoClick"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
  
<script setup>
import { ref, onMounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';
import Horario from '/src/components/Horario.vue';
import SeletorTurnosInscritos from '/src/components/director/Seletor.vue';

const route = useRoute();
const studentId = ref('');
const selectedShifts = ref([]);

// Initialize studentId with a default value
const storedUserId = localStorage.getItem('userId');
studentId.value = storedUserId;

// Função para buscar alocações do aluno
const fetchStudentAllocations = async (id) => {
  try {
    console.log("Buscando alocações para o aluno ID:", id);
    const response = await axios.get(`http://localhost:3000/allocations?studentId=${id}`);
    if (response.data && response.data.length > 0) {
      console.log("Alocações encontradas:", response.data.length);
      // Convert all IDs to numbers to ensure consistency
      selectedShifts.value = response.data.map(allocation => Number(allocation.shiftId));
      console.log("Turnos selecionados:", selectedShifts.value);
    } else {
      console.log("Nenhuma alocação encontrada para o aluno");
      selectedShifts.value = [];
    }
  } catch (error) {
    console.error('Erro ao buscar alocações do aluno:', error);
    selectedShifts.value = [];
  }
};

// Manipular clique em um turno no horário
const handleTurnoClick = (turnoId) => {
  // Convert to number for consistency
  const numericId = Number(turnoId);
  
  // Se o turno já está selecionado, remova-o
  if (selectedShifts.value.includes(numericId)) {
    selectedShifts.value = selectedShifts.value.filter(id => id !== numericId);
  } 
  // Caso contrário, adicione-o
  else {
    selectedShifts.value.push(numericId);
  }
  
  console.log("Turnos após clique:", selectedShifts.value);
};

// Manipular mudanças na seleção do seletor
const handleSelectionChange = (shifts) => {
  console.log("Seleção alterada recebida:", shifts);
  
  // Ensure we're working with numbers
  if (Array.isArray(shifts)) {
    selectedShifts.value = shifts.map(id => Number(id));
  } else if (shifts && typeof shifts === 'object') {
    // Handle proxy objects by converting to array
    const shiftArray = [];
    for (let i = 0; i < Object.keys(shifts).length; i++) {
      if (shifts[i] !== undefined) {
        shiftArray.push(Number(shifts[i]));
      }
    }
    selectedShifts.value = shiftArray;
  } else {
    selectedShifts.value = [];
  }
  
  console.log("Turnos após seleção:", selectedShifts.value);
};

onMounted(async () => {
  // Obter ID do aluno da rota ou do localStorage
  if (route.params.studentId) {
    studentId.value = route.params.studentId;
  }
  
  console.log("ID do aluno:", studentId.value);
  
  // Buscar alocações do aluno
  await fetchStudentAllocations(studentId.value);
});
</script>
