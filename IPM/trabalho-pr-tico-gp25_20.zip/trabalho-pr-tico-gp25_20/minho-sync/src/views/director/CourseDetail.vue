<template>
    <div class="course-detail-container">
      <div v-if="loading" class="flex justify-center items-center h-64">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-600"></div>
      </div>
      
      <div v-else>
        <!-- Cabeçalho da página -->
        <div class="p-6 rounded-lg">
          <div class="flex items-center mb-4">
            <div class="text-red-600 mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h1 class="text-2xl font-bold">{{ curso.nome }}</h1>
          </div>
  
          
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
            <div>
              <span class="font-semibold">Regente:</span> {{ curso.regente }}
            </div>
            <div>
              <span class="font-semibold">Ano:</span> {{ curso.ano }}º Ano
            </div>
            <div>
              <span class="font-semibold">Semestre:</span> {{ curso.semestre }}º Semestre
            </div>
            <div>
              <span class="font-semibold">Tipo da UC:</span> {{ curso.tipo }}
            </div>
            <div>
              <span class="font-semibold">Total de Alunos Inscritos:</span> {{ curso.totalAlunos }} alunos
            </div>
          </div>
        </div>
        
        <!-- Tabela de turnos -->
        <div class="bg-gray rounded-lg p-6">
          <div class="rounded-lg  mb-6">
            <h2 class="text-xl font-bold mb-4">Turnos</h2>
            
            <div class="overflow-x-auto">
              <table class="w-full">
                <thead>
                  <tr class="border-b text-left text-red-600">
                    <th class="py-3 px-4">Turno</th>
                    <th class="py-3 px-4">Sala</th>
                    <th class="py-3 px-4">Horário</th>
                    <th class="py-3 px-4">Docente</th>
                    <th class="py-3 px-4 text-center">Ocupação</th>
                    <th class="py-3 px-4 text-right"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="turno in turnos" :key="turno.id" class="border-b hover:bg-gray-50 cursor-pointer" @click="() => router.push(`/director/course/${curso.id}/shift/${turno.id}`)">
                    <td class="py-4 px-4">{{ turno.nome }}</td>
                    <td class="py-4 px-4">{{ turno.sala }}</td>
                    <td class="py-4 px-4">{{ turno.horario }}</td>
                    <td class="py-4 px-4">{{ turno.docente }}</td>
                    <td class="py-4 px-4">
                      <div class="flex items-center justify-center">
                        <div class="w-full bg-white rounded-full p-1.5 shadow-sm">
                          <div class="bg-gray-100 rounded-full w-full">
                            <div 
                              class="h-3 rounded-full transition-all duration-300 ease-in-out" 
                              :class="getProgressBarColor(turno.ocupacaoPercentual)"
                              :style="{ width: `${turno.ocupacaoPercentual}%` }"
                            ></div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td class="py-4 px-4 text-right whitespace-nowrap">
                      {{ turno.ocupacaoPercentual }}% {{ turno.alunosAtuais }}/{{ turno.capacidadeTotal }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- Notas -->
          <div class="mb-6">
            <h2 class="text-xl font-bold mb-4">Notas:</h2>
            <div class="border bg-white rounded-lg p-4 mb-4">
              <textarea 
              v-model="curso.notas" 
              class="w-full min-h-[100px] focus:outline-none resize-none"
              placeholder="Adicione notas sobre este curso..."
              ></textarea>
            </div>
            <div class="flex justify-between items-center">
              <p class="text-sm text-gray-500">Última atualização: {{ curso.ultimaAtualizacao }}</p>
              <button 
              @click="salvarNotas" 
              class="bg-red-700 hover:bg-red-800 text-white py-1 px-4 rounded-md text-sm"
              >
              Salvar Notas
            </button>
          </div>
        </div>
  
        <!-- Botão Voltar -->
        <button 
          @click="voltar" 
          class="bg-red-700 hover:bg-red-800 text-white py-2 px-6 rounded-md"
        >
          Voltar
        </button>
    </div>
    </div>
  </div>
    </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import axios from 'axios';
  
  const route = useRoute();
  const router = useRouter();
  const courseId = route.params.courseId;
  
  const curso = ref({
    id: null,
    nome: '',
    regente: '',
    ano: '',
    semestre: '',
    tipo: '',
    totalAlunos: 0,
    notas: 'Turno PL1 com capacidade cheia, considerar mudar para uma sala maior.',
    ultimaAtualizacao: '05/02/2023, 14:02:21'
  });
  
  const turnos = ref([]);
  const loading = ref(true);
  
  // Função para voltar à página anterior
  const voltar = () => {
    router.push('/director/dashboard');
  };

    // Função para salvar as notas
    const salvarNotas = async () => {
    try {
      // Atualizar a data de última atualização
      curso.value.ultimaAtualizacao = new Date().toLocaleString();
    
    } catch (error) {
      console.error('Erro ao salvar notas:', error);
      alert('Erro ao salvar notas. Por favor, tente novamente.');
    }
  };
  
  // Mapear dias da semana
  const mapDiaSemana = (dia) => {
    const diasMap = {
      'Monday': 'Segunda-feira',
      'Tuesday': 'Terça-feira',
      'Wednesday': 'Quarta-feira',
      'Thursday': 'Quinta-feira',
      'Friday': 'Sexta-feira'
    };
    return diasMap[dia] || dia;
  };
  
  const getProgressBarColor = (percentagem) => {
  if (percentagem >= 75) return "bg-red-500";
  if (percentagem >= 45) return "bg-yellow-500";
  return "bg-green-500";
};

  const fetchCourseData = async () => {
    try {
      loading.value = true;
      
      const courseResponse = await axios.get(`http://localhost:3000/courses?id=${courseId}`);
      let courseData = courseResponse.data;
        console.log('Dados do curso:', courseData);
      
      if (Array.isArray(courseData) && courseData.length > 0) {
        courseData = courseData[0];
      }
      
      const teachersResponse = await axios.get('http://localhost:3000/teachers');
      const teachers = teachersResponse.data;
      console.log('Professores:', teachers);
      
      const classroomsResponse = await axios.get('http://localhost:3000/classrooms');
      const classrooms = classroomsResponse.data;
      console.log('Salas:', classrooms);

    console.log('ID do curso:', courseId);
        const shiftsResponse = await axios.get(`http://localhost:3000/shifts?courseId=${courseId}`);
        const courseShifts = shiftsResponse.data;
        const courseShiftIds = courseShifts.map(shift => shift.id);
        console.log('Turnos:', courseShifts);
      
      const allocations = [];
      for (let index = 0; index < courseShiftIds.length; index++) {
        console.log('ID do turno:', courseShiftIds[index]);
        const id = courseShiftIds[index]
        const allocationsResponse = await axios.get(`http://localhost:3000/allocations?shiftId=${id}`);
        allocations.push(...allocationsResponse.data);
      }
      console.log('Alocações:', allocations);

      
      const firstShiftTeacherId = courseShifts[0]?.teacherId;
    const regente = teachers.find(t => t.id == firstShiftTeacherId)?.name || 'Professor não especificado';


      curso.value = {
        id: courseData.id,
        nome: courseData.name,
        regente: regente,
        ano: courseData.year,
        semestre: courseData.semester,
        tipo: 'Obrigatória',
        totalAlunos: allocations.length || 0,
        notas: 'Turno PL1 com capacidade cheia, considerar mudar para uma sala maior.',
        ultimaAtualizacao: '05/02/2023, 14:02:21'
      };
      
      // Preparar dados dos turnos
      const turnosProcessados = courseShifts.map(shift => {
        // Encontrar a sala
        const classroom = classrooms.find(c => c.id == shift.classroomId);
        const roomCapacity = classroom?.capacity || 100;
        
        // Contar alocações para este turno
        const shiftAllocations = allocations.filter(a => a.shiftId == shift.id);
        const alunosAlocados = shiftAllocations.length || shift.totalStudentsRegistered || 0;
        
        // Calcular percentual de ocupação
        const ocupacaoPercentual = Math.round((alunosAlocados / roomCapacity) * 100);
        
        // Encontrar o professor
        const teacher = teachers.find(t => t.id == shift.teacherId);
        
        // Formatar o horário
        const diaSemana = mapDiaSemana(shift.day);
        const horario = `${diaSemana}, ${shift.from}:00 - ${shift.to}:00`;

        return {
          id: shift.id,
          nome: shift.name,
          sala: classroom?.name || 'Sala não especificada',
          horario: horario,
          docente: teacher?.name || 'Professor não especificado',
          ocupacaoPercentual: ocupacaoPercentual,
          alunosAtuais: alunosAlocados,
          capacidadeTotal: roomCapacity
        };
      });
      
      turnos.value = turnosProcessados;
      loading.value = false;
    } catch (error) {
      console.error('Erro ao buscar dados do curso:', error);
      loading.value = false;
    }
  };
  
  // Carregar dados ao montar o componente
  onMounted(fetchCourseData);
  </script>
  
  <style scoped>
  .course-detail-container {
    background-color: #f7fafc;
    min-height: 100vh;
    padding: 1.5rem;
  }
  
  /* Estilo para as barras de progresso */
  .progress-bar {
    height: 10px;
    border-radius: 5px;
    transition: width 0.5s ease-in-out;
  }
  textarea {
    font-family: inherit;
    line-height: 1.5;
    border: none;
    background: transparent;
  }
  
  textarea:focus {
    outline: none;
  }

  </style>