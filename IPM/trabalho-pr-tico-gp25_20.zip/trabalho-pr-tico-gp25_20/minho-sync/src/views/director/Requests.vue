<template>
  <div class="font-sans p-6 space-y-6">
    <!-- Título -->
    <h2 class="text-xl font-bold text-gray-800">Gestão de Pedidos</h2>
    <!-- Resumo -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div class="bg-gray p-6 rounded-xl shadow-lg transition-shadow duration-300 relative">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"  class="text-black absolute top-7 right-7 w-7 h-7">
            <path d="M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288-128 0c-17.7 0-32-14.3-32-32L224 0 64 0zM256 0l0 128 128 0L256 0zM112 256l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64l160 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16z"/>
          </svg>
        <h3 class="text-lg font-semibold mb-2">Total de Pedidos</h3>
        <p class="text-3xl font-bold text-gray-800">{{ totalPedidos }}</p>
      </div>
      <div class="bg-gray p-6 rounded-xl shadow-lg transition-shadow duration-300 relative">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" class="text-black absolute top-7 right-7 w-7 h-7">
          <path d="M32 0C14.3 0 0 14.3 0 32S14.3 64 32 64l0 11c0 42.4 16.9 83.1 46.9 113.1L146.7 256 78.9 323.9C48.9 353.9 32 394.6 32 437l0 11c-17.7 0-32 14.3-32 32s14.3 32 32 32l32 0 256 0 32 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-11c0-42.4-16.9-83.1-46.9-113.1L237.3 256l67.9-67.9c30-30 46.9-70.7 46.9-113.1l0-11c17.7 0 32-14.3 32-32s-14.3-32-32-32L320 0 64 0 32 0zM96 75l0-11 192 0 0 11c0 19-5.6 37.4-16 53L112 128c-10.3-15.6-16-34-16-53zm16 309c3.5-5.3 7.6-10.3 12.1-14.9L192 301.3l67.9 67.9c4.6 4.6 8.6 9.6 12.1 14.9L112 384z"/>
        </svg>
        <h3 class="text-lg font-semibold mb-2">Pendentes</h3>
        <p class="text-3xl font-bold text-gray-800">{{ pendentes }}</p>
      </div>
      <div class="bg-gray p-6 rounded-xl shadow-lg transition-shadow duration-300 relative">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="text-black absolute top-7 right-7 w-7 h-7">
          <path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"/>
        </svg>
        <h3 class="text-lg font-semibold mb-2">Aprovados</h3>
        <p class="text-3xl font-bold text-gray-800">{{ aprovados }}</p>
      </div>
      <div class="bg-gray p-6 rounded-xl shadow-lg transition-shadow duration-300 relative">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="text-black absolute top-7 right-7 w-7 h-7">
          <path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c9.4-9.4 24.6-9.4 33.9 0l47 47 47-47c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-47 47 47 47c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-47-47-47 47c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l47-47-47-47c-9.4-9.4-9.4-24.6 0-33.9z"/>
        </svg>
        <h3 class="text-lg font-semibold mb-2">Rejeitados</h3>
        <p class="text-3xl font-bold text-gray-800">{{ rejeitados }}</p>
      </div>
    </div>

    <!-- Filtro  -->
    <div class="flex justify-end">
      <div class="relative">
        <select 
                id="filter"
                v-model="selectedFilter" 
                class="bg-gray-200 rounded-md px-3 py-1 pr-8 appearance-none"
              >
          <option value="all">Todos</option>
          <option value="pendente">Pendentes</option>
          <option value="aprovado">Aprovados</option>
          <option value="rejeitado">Rejeitados</option>
        </select>
        <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </div>
      </div>
    </div>

    <!-- Tabela -->
    <div class="overflow-x-auto rounded-lg">
      <table class="w-full border-collapse rounded-lg shadow-sm">
        <thead>
          <tr class="bg-red-800 text-white">
            <th class="py-3 px-4">ID</th>
            <th class="py-3 px-4">Nome</th>
            <th class="py-3 px-4">Tipo</th>
            <th class="py-3 px-4">Unidade Curricular</th>
            <th class="py-3 px-4">Status</th>
            <th class="py-3 px-4">Ações</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="pedido in paginatedPedidos" :key="pedido.id" class="text-center border-b">
            <td class="py-2 px-4">{{ pedido.id }}</td>
            <td class="py-2 px-4">{{ pedido.nome }}</td>
            <td class="py-2 px-4">{{ pedido.tipo }}</td>
            <td class="py-2 px-4">{{ pedido.unidadeCurricular }}</td>
            <td class="py-2 px-4 font-semibold" :class="{
              'text-yellow-500': pedido.status === 'Pendente',
              'text-green-500': pedido.status === 'Aprovado',
              'text-red-500': pedido.status === 'Rejeitado'
            }">
              {{ pedido.status }}
            </td>
            <td class="py-2 px-4">
              <div class="flex justify-center space-x-2">
                <button @click="rejeitarPedido(pedido)"
                  class="text-white rounded-md w-8 h-8 flex items-center justify-center bg-red-700 hover:bg-red-800"
                  title="Rejeitar Pedido">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"  class="m-1.5 text-white" fill="currentColor">
                    <path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/>
                  </svg>
                </button>
                <button @click="aprovarPedido(pedido)"
                  class="text-white rounded-md w-8 h-8 flex items-center justify-center bg-red-700 hover:bg-red-800"
                  title="Aprovar Pedido">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="m-1.5 text-white" fill="currentColor">
                    <path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"/>
                  </svg>
                </button>
                <router-link :to="`/director/requests/${pedido.type}/${pedido.id}`"
                  class="text-white rounded-md w-8 h-8 flex items-center justify-center bg-red-700 hover:bg-red-800"
                  title="Ver Pedido">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="m-1.5 text-white" fill="currentColor">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/>
                  </svg>
                </router-link>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Paginação -->
    <div class="flex justify-between items-center text-sm text-gray-600 mt-2">
      <span>A mostrar {{ paginatedPedidos.length }} de {{ filteredPedidos.length }} resultados</span>
      <div class="space-x-1">
        <button v-for="page in totalPages" :key="page" @click="currentPage = page" class="px-3 py-1" :class="{
          'text-red-700 font-bold': currentPage === page,
          'text-gray-600 hover:text-gray-800': currentPage !== page
        }">
          {{ page }}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      pedidos: [],
      selectedFilter: 'all',
      currentPage: 1,
      itemsPerPage: 5
    }
  },
  computed: {
    filteredPedidos() {
      if (this.selectedFilter === 'all') return this.pedidos
      return this.pedidos.filter(p =>
        p.status.toLowerCase() === this.selectedFilter.toLowerCase()
      )
    },
    paginatedPedidos() {
      const start = (this.currentPage - 1) * this.itemsPerPage
      return this.filteredPedidos.slice(start, start + this.itemsPerPage)
    },
    totalPedidos() {
      return this.pedidos.length
    },
    pendentes() {
      return this.pedidos.filter(p => p.status === 'Pendente').length
    },
    aprovados() {
      return this.pedidos.filter(p => p.status === 'Aprovado').length
    },
    rejeitados() {
      return this.pedidos.filter(p => p.status === 'Rejeitado').length
    },
    totalPages() {
      return Math.ceil(this.filteredPedidos.length / this.itemsPerPage)
    }
  },
  methods: {
    async fetchPedidos() {
      const [shiftsRes, roomsRes, studentsRes, teachersRes, shiftsList, coursesRes] = await Promise.all([
        axios.get('http://localhost:3000/shiftRequests'),
        axios.get('http://localhost:3000/classroomRequests'),
        axios.get('http://localhost:3000/students'),
        axios.get('http://localhost:3000/teachers'),
        axios.get('http://localhost:3000/shifts'),
        axios.get('http://localhost:3000/courses')
      ])

      const getStudentName = id => studentsRes.data.find(s => s.id == id)?.name || `Aluno #${id}`
      const getTeacherName = id => teachersRes.data.find(t => t.id == id)?.name || `Docente #${id}`
      const getCourseNameFromShift = shiftId => {
        const shift = shiftsList.data.find(s => s.id == shiftId)
        const course = coursesRes.data.find(c => c.id == shift?.courseId)
        return course ? course.name : `Turno ${shiftId}`
      }

      const shiftPedidos = shiftsRes.data.map(p => ({
        id: `${p.id}`,
        type: 'shift',
        nome: getStudentName(p.studentId),
        tipo: 'Mudança de Turno',
        unidadeCurricular: getCourseNameFromShift(p.shiftId),
        status: this.mapStatus(p.response)
      }))

      const salaPedidos = roomsRes.data.map(p => ({
        id: `${p.id}`,
        type: 'classroom',
        nome: getTeacherName(p.teacherId),
        tipo: 'Pedido de Sala',
        unidadeCurricular: `Sala ${p.classroomId}`,
        status: this.mapStatus(p.response)
      }))

      this.pedidos = [...shiftPedidos, ...salaPedidos]
    },
    mapStatus(response) {
      if (response === 'ok') return 'Aprovado'
      if (response === 'rejected') return 'Rejeitado'
      return 'Pendente'
    },
    async aprovarPedido(pedido) {
      const isShift = pedido.id.startsWith('S')
      const endpoint = isShift ? 'shiftRequests' : 'classroomRequests'
      const realId = pedido.id.slice(1)

      try {
        await axios.patch(`http://localhost:3000/${endpoint}/${realId}`, {
          response: 'ok'
        })
        pedido.status = this.mapStatus('ok')
      } catch (error) {
        console.error('Erro ao aprovar pedido:', error)
      }
    },
    async rejeitarPedido(pedido) {
      const isShift = pedido.id.startsWith('S')
      const endpoint = isShift ? 'shiftRequests' : 'classroomRequests'
      const realId = pedido.id.slice(1)

      try {
        await axios.patch(`http://localhost:3000/${endpoint}/${realId}`, {
          response: 'rejected'
        })
        pedido.status = this.mapStatus('rejected')
      } catch (error) {
        console.error('Erro ao rejeitar pedido:', error)
      }
    }
  },
  mounted() {
    this.fetchPedidos()
  }
}
</script>