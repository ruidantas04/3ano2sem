<template>
  <div class="pt-[20px] px-[20px] pb-[20px]">
    <div class="flex flex-col space-y-4">
      <div class="flex flex-row space-x-4">
        <div class="w-1/2 bg-gray-100 rounded-lg shadow-md px-4">
          <h2 class="text-xl font-bold py-6">Resultado da Geração de Turnos</h2>
          <div class="bg-red-800 rounded-t-lg overflow-hidden">
            <div class="flex">
              <button 
                v-for="ano in anos" 
                :key="ano.value" 
                class="flex-1 py-3 px-4 text-center font-medium transition-colors cursor-pointer"
                :class="anoSelecionado === ano.value ? 'bg-red-900 text-white' : 'bg-red-800 text-white hover:bg-red-700'"
                @click="navegarParaUCsDoAno(ano.value)"                
              >
                {{ ano.label }}
              </button>
            </div>
          </div>
          
          <!-- Gráfico de Alocações -->
          <div class="p-4">
      <div class="h-64">
        <div class="flex h-full">
          <!-- Eixo Y com valores -->
          <div class="w-12 flex flex-col justify-between items-end pr-2">
            <span class="text-sm text-gray-600">160</span>
            <span class="text-sm text-gray-600">120</span>
            <span class="text-sm text-gray-600">80</span>
            <span class="text-sm text-gray-600">40</span>
            <span class="text-sm text-gray-600">0</span>
          </div>
      
      <!-- Barras do gráfico -->
      <div class="flex-1 flex justify-around items-end">
        <div v-for="(estatistica, index) in estatisticasPorAno" :key="index" class="flex flex-col items-center w-20">
          <!-- Grupo de barras - Agora com items-end para alinhar na parte inferior -->
          <div class="flex space-x-1 h-[200px] items-end">
            <!-- Barra de Alocados -->
            <div class="relative w-8 bg-dark-red" :style="{ height: `${(estatistica.alocados / 160) * 200}px` }">
              <!-- Rótulo com o número de alocados -->
              <div class="absolute -top-6 w-full text-center text-xs font-semibold">
                {{ estatistica.alocados }}
              </div>
            </div>
            
            <!-- Barra de Não Alocados -->
            <div class="relative w-8 bg-red" :style="{ height: `${(estatistica.naoAlocados / 160) * 200}px` }">
              <!-- Rótulo com o número de não alocados -->
              <div class="absolute -top-6 w-full text-center text-xs font-semibold">
                {{ estatistica.naoAlocados }}
              </div>
            </div>
          </div>
          
          <!-- Rótulo do Ano - Movido para baixo das barras -->
          <div class="text-sm font-medium mt-2 cursor-pointer" @click="filtrarParaUCsDoAno(estatistica.ano)">{{ estatistica.label }}</div>
        </div>
      </div>
    </div>
    
    <!-- Legenda -->
    <div class="flex justify-center mt-6 cursor-pointer" @click="filtrarParaUCsDoAno(null)">
      <div class="flex items-center mr-6">
        <div class="w-4 h-4 bg-dark-red mr-2"></div>
        <span class="text-sm">Alocados</span>
      </div>
      <div class="flex items-center">
        <div class="w-4 h-4 bg-red mr-2"></div>
        <span class="text-sm">Não Alocados</span>
      </div>
    </div>
  </div>
</div>
        </div>
        
        <!-- Coluna da direita: Alunos pendentes -->
        <div class="w-1/2 bg-gray-100 rounded-lg shadow-md px-4">
          <h2 class="text-xl font-bold pt-6">Alunos pendentes de alocação</h2>
          <!-- Alerta -->
          <div class="p-4 bg-white border border-red-200 rounded-lg my-3 flex items-center">
            <div class="text-red-500 mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <span class="text-red-800">
              {{ alunosPendentes.length }} Alunos precisam de alocação manual!
            </span>
          </div>
          
          <!-- Tabela de Alunos -->
          <div class="overflow-x-auto max-h-[70vh] rounded-lg">
            <table class="w-full border-collapse">
              <thead>
                <tr class="bg-red-800 text-white">
                  <th class="py-3 px-4 text-left">Estudante</th>
                  <th class="py-3 px-4 text-left">Número</th>
                  <th class="py-3 px-4 text-left">Ano</th>
                  <th class="py-3 px-4 text-left">Estatuto</th>
                  <th class="py-3 px-4 text-left">UC Pendente</th>
                  <th class="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody>
                <tr 
                  v-for="(item, index) in alunosPendentes" 
                  :key="index"
                  :class="index % 2 === 0 ? 'bg-white' : 'bg-gray-50'"
                  class="border-b border-gray-200"
                >
                  <td class="py-3 px-4">{{ item.aluno.name }}</td>
                  <td class="py-3 px-4">{{ getNumeroAluno(item.aluno) }}</td>
                  <td class="py-3 px-4">{{ `${item.ano}º Ano` }}</td>
                  <td class="py-3 px-4">{{ getStatusAluno(item.aluno) }}</td>
                  <td class="py-3 px-4">
                    <div class="flex flex-col">
                      <span v-for="(uc, ucIndex) in item.ucs" :key="ucIndex" class="text-sm">
                        {{ uc.name }}
                      </span>
                    </div>
                  </td>
                  <td class="py-3 px-4 text-center">
                    <button 
                      class="bg-red-800 hover:bg-red-700 text-white py-1 px-4 rounded-full text-sm transition-colors"
                      @click="alocarAluno(item.aluno)"
                    >
                      Alocar
                    </button>
                  </td>
                </tr>
                <tr v-if="alunosPendentes.length === 0">
                  <td colspan="6" class="py-4 text-center text-gray-500">
                    Não há alunos pendentes de alocação{{ anoSelecionado ? ' para o ano selecionado' : '' }}.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';

// Router para navegação
const router = useRouter();

// URLs do JSON Server
const STUDENTS_URL = `http://localhost:3000/students`;
const ALLOCATIONS_URL = `http://localhost:3000/allocations`;
const SHIFTS_URL = `http://localhost:3000/shifts`;
const COURSES_URL = `http://localhost:3000/courses`;

// Estado
const alunos = ref([]);
const alocacoes = ref([]);
const turnos = ref([]);
const cursos = ref([]);
const loading = ref(true);
const error = ref(null);
const anoSelecionado = ref(null);

// Definição dos anos
const anos = [
  { value: 1, label: '1º Ano' },
  { value: 2, label: '2º Ano' },
  { value: 3, label: '3º Ano' }
];

// Buscar dados
const fetchData = async () => {
  loading.value = true;
  try {

    // Buscar dados em sequência para garantir que todos estejam carregados
    const coursesResponse = await axios.get(COURSES_URL);
    cursos.value = coursesResponse.data;

    const shiftsResponse = await axios.get(SHIFTS_URL);
    turnos.value = shiftsResponse.data;

    const allocationsResponse = await axios.get(ALLOCATIONS_URL);
    alocacoes.value = allocationsResponse.data;

    const studentsResponse = await axios.get(STUDENTS_URL);
    alunos.value = studentsResponse.data;

    console.log("Dados carregados:");
    console.log("Cursos:", cursos.value.length);
    console.log("Turnos:", turnos.value.length);
    console.log("Alocações:", alocacoes.value.length);
    console.log("Alunos:", alunos.value.length);
    
    // Debug: Verificar alguns dados de exemplo
    if (alunos.value.length > 0 && cursos.value.length > 0) {
      const alunoExemplo = alunos.value[0];
      console.log("Aluno exemplo:", alunoExemplo.name, "ID:", alunoExemplo.id);
      console.log("Cadeiras inscritas:", alunoExemplo.enrolled);
      
      if (alunoExemplo.enrolled && alunoExemplo.enrolled.length > 0) {
        const cursoExemplo = alunoExemplo.enrolled[0];
        console.log("Verificando alocação para curso ID:", cursoExemplo);
        
        // Verificar se o aluno está alocado neste curso
        const estaAlocado = alunoEstaAlocadoEmUC(alunoExemplo.id, cursoExemplo);
        console.log("Está alocado?", estaAlocado);
        
        // Verificar turnos deste curso
        const turnosDoCurso = turnos.value.filter(t => t.courseId == cursoExemplo);
        console.log("Turnos do curso:", turnosDoCurso);
        
        // Verificar alocações deste aluno
        const alocacoesDoAluno = alocacoes.value.filter(a => a.studentId == alunoExemplo.id);
        console.log("Alocações do aluno:", alocacoesDoAluno);
      }
    }

  } catch (err) {
    console.error('Erro ao buscar dados:', err);
    error.value = 'Erro ao carregar dados. Por favor, tente novamente.';
  } finally {
    loading.value = false;
  }
};

// Função para obter o número do aluno a partir do email
const getNumeroAluno = (aluno) => {
  if (!aluno || !aluno.email) return 'N/A';
  const match = aluno.email.match(/^[a-z]?(\d+)@/);
  return match ? match[1] : 'N/A';
};

// Função para obter o status do aluno
const getStatusAluno = (aluno) => {
  return aluno.specialStatus ? 'Especial' : 'Regular';
};

// Função para navegar para as UCs de um determinado ano
const navegarParaUCsDoAno = (ano) => {
  router.push('/director/manual-UC-allocation/' + ano);
};

const filtrarParaUCsDoAno = (ano) => {
  anoSelecionado.value = ano;
};


// Função para verificar se um aluno está alocado em uma UC específica
// FUNÇÃO CORRIGIDA: Problema estava na comparação de tipos e na lógica de verificação
const alunoEstaAlocadoEmUC = (alunoId, cursoId) => {
  // Debug: Mostrar os tipos de dados
  console.log(`Verificando alocação - alunoId: ${alunoId} (${typeof alunoId}), cursoId: ${cursoId} (${typeof cursoId})`);
  
  // Garantir que estamos trabalhando com números para comparação
  const alunoIdNum = Number(alunoId);
  const cursoIdNum = Number(cursoId);
  
  // Obter todos os turnos desta UC
  const turnosDaUC = turnos.value.filter(turno => Number(turno.courseId) === cursoIdNum);
  
  // Debug: Verificar turnos encontrados
  console.log(`Turnos encontrados para curso ${cursoIdNum}:`, turnosDaUC.length);
  
  if (turnosDaUC.length === 0) {
    console.log(`Nenhum turno encontrado para o curso ${cursoIdNum}`);
    return false;
  }
  
  const turnosIds = turnosDaUC.map(turno => Number(turno.id));
  console.log(`IDs dos turnos:`, turnosIds);
  
  // Verificar se o aluno tem alguma alocação em qualquer turno desta UC
  const alocacoesDoAluno = alocacoes.value.filter(alocacao => Number(alocacao.studentId) === alunoIdNum);
  console.log(`Alocações do aluno ${alunoIdNum}:`, alocacoesDoAluno.length);
  
  // Verificar se alguma das alocações do aluno corresponde a um dos turnos da UC
  const estaAlocado = alocacoesDoAluno.some(alocacao => 
    turnosIds.includes(Number(alocacao.shiftId))
  );
  
  console.log(`Aluno ${alunoIdNum} está alocado no curso ${cursoIdNum}? ${estaAlocado}`);
  
  return estaAlocado;
};

// Computed property para obter as UCs por ano
const ucsPorAno = computed(() => {
  const resultado = {};

  // Agrupar UCs por ano
  cursos.value.forEach(curso => {
    if (!resultado[curso.year]) {
      resultado[curso.year] = [];
    }
    resultado[curso.year].push(curso);
  });

  return resultado;
});

// Computed property para obter estatísticas de alocação por UC
const estatisticasPorUC = computed(() => {
  const resultado = {};

  cursos.value.forEach(curso => {
    // Contar alunos inscritos nesta UC
    const alunosInscritos = alunos.value.filter(aluno =>
      aluno.enrolled && aluno.enrolled.includes(Number(curso.id))
    );

    // Contar alunos alocados nesta UC
    const alunosAlocados = alunosInscritos.filter(aluno =>
      alunoEstaAlocadoEmUC(aluno.id, curso.id)
    );

    resultado[curso.id] = {
      curso: curso,
      totalInscritos: alunosInscritos.length,
      alocados: alunosAlocados.length,
      naoAlocados: alunosInscritos.length - alunosAlocados.length
    };
  });

  return resultado;
});

// Computed property para obter estatísticas de alocação por ano
const estatisticasPorAno = computed(() => {
  const resultado = [];

  // Para cada ano, calcular estatísticas agregadas
  for (let ano = 1; ano <= 3; ano++) {
    const ucsDoAno = cursos.value.filter(curso => curso.year === ano);

    let totalAlocados = 0;
    let totalNaoAlocados = 0;

    ucsDoAno.forEach(uc => {
      const estatistica = estatisticasPorUC.value[uc.id];
      if (estatistica) {
        totalAlocados += estatistica.alocados;
        totalNaoAlocados += estatistica.naoAlocados;
      }
    });

    resultado.push({
      ano: ano,
      label: `${ano}º Ano`,
      alocados: totalAlocados,
      naoAlocados: totalNaoAlocados
    });
  }

  return resultado;
});

// Computed property para obter alunos pendentes de alocação
const alunosPendentes = computed(() => {
  const resultado = [];

  // Se um ano específico foi selecionado, filtrar apenas para esse ano
  const alunosFiltrados = anoSelecionado.value
    ? alunos.value.filter(aluno => {
        if (!aluno.enrolled) return false;
        return aluno.enrolled.some(cursoId => {
          const curso = cursos.value.find(c => Number(c.id) === Number(cursoId));
          return curso && curso.year === anoSelecionado.value;
        });
      })
    : alunos.value;

  // Para cada aluno
  alunosFiltrados.forEach(aluno => {
    // Agrupar UCs pendentes por ano
    const ucsPendentesPorAno = {};

    // Verificar cada UC em que o aluno está inscrito
    if (aluno.enrolled && aluno.enrolled.length > 0) {
      aluno.enrolled.forEach(cursoId => {
        const curso = cursos.value.find(c => Number(c.id) === Number(cursoId));

        if (curso) {
          // Verificar se o aluno está alocado nesta UC
          const estaAlocado = alunoEstaAlocadoEmUC(aluno.id, curso.id);

          // Se não estiver alocado, adicionar à lista de pendentes
          if (!estaAlocado) {
            if (!ucsPendentesPorAno[curso.year]) {
              ucsPendentesPorAno[curso.year] = [];
            }
            ucsPendentesPorAno[curso.year].push(curso);
          }
        }
      });
    }

    // Para cada ano com UCs pendentes, criar uma entrada na lista
    Object.keys(ucsPendentesPorAno).forEach(ano => {
      // Se um ano específico foi selecionado, filtrar apenas para esse ano
      if (!anoSelecionado.value || anoSelecionado.value === Number(ano)) {
        resultado.push({
          aluno: aluno,
          ano: Number(ano),
          ucs: ucsPendentesPorAno[ano]
        });
      }
    });
  });

  return resultado;
});

const alocarAluno = (aluno) => {
  router.push(`/director/student/${aluno.id}`);
};


// Carregar dados ao montar o componente
onMounted(() => {
  fetchData();
});
</script>
