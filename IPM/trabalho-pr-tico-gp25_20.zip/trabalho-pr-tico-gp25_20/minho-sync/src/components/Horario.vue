<template>
  <div class="w-full overflow-x-auto">
    <div v-if="loading" class="p-8 text-center text-gray-500">
      Carregando horário...
    </div>
    <div v-else-if="error" class="p-8 text-center text-red-500">
      {{ error }}
    </div>
    <div v-else class="horario-container">
      <table class="w-full border-collapse border border-gray-300">
        <thead>
          <tr>
            <th class="border border-gray-300 p-2 w-10"></th>
            <th 
              v-for="dia in diasSemana" 
              :key="dia" 
              class="border border-gray-300 p-2 text-center font-medium w-1/5"
            >
              {{ dia }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="hora in horas" :key="hora" class="border border-gray-300">
            <td class="border border-gray-300 p-2 text-center text-sm">{{ hora }}h</td>
            <template v-for="dia in diasSemana" :key="`${hora}-${dia}`">
              <template v-if="!celulasOcupadas[`${hora}-${dia}`]">
                <template v-if="getTurnosIniciandoEm(hora, dia).length > 0">
                  <td 
                    class="border border-gray-300 p-0 relative time-slot"
                    :rowspan="calcularRowspan(getTurnosIniciandoEm(hora, dia)[0])"
                  >
                    <div class="h-full w-full flex">
                      <template v-for="turno in getTurnosIniciandoEm(hora, dia)" :key="turno.id">
                        <div 
                          class="p-2 flex-1 rounded-md m-0.5 overflow-hidden cursor-pointer transition-all duration-200 hover:brightness-90"
                          :class="[getCorPorAno(turno.courseId)]"
                          @click="abrirDetalhes(turno)"
                        >
                          <div class="font-medium text-sm">
                            {{ getCursoAbreviacao(turno.courseId) }} - {{ turno.name }}
                          </div>
                          <div class="text-xs">
                            {{ getSalaInfo(turno) }}
                          </div>
                        </div>
                      </template>
                    </div>
                  </td>
                </template>
                <td v-else class="border border-gray-300 p-0 relative time-slot"></td>
              </template>
            </template>
          </tr>
        </tbody>
      </table>
      
      <!-- Modal de detalhes do turno -->
      <div 
        v-if="turnoSelecionado" 
        class="fixed inset-0 flex items-center justify-center z-50 fundo-escuro"
        @click.self="fecharDetalhes"
      >
        <div 
          class="bg-gray border border-gray-300 p-6 rounded-xl shadow-xl max-w-md w-full mx-4"
        >
          <h2 class="text-xl font-bold mb-4 border-b border-gray-600 pb-2">
            {{ getCursoNome(turnoSelecionado.courseId) }}
          </h2>
          
          <div class="space-y-3">
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <span>{{ getAnoSemestre(turnoSelecionado.courseId) }}</span>
            </div>
            
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>{{ formatHorario(turnoSelecionado) }}</span>
            </div>
            
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span>{{ getSalaCompleta(turnoSelecionado) }}</span>
            </div>
            
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <span>{{ turnoSelecionado.name }}</span>
            </div>
            
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <span>{{ getProfessorNome(turnoSelecionado.teacherId) }}</span>
            </div>
            
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <span>{{ turnoSelecionado.totalStudentsRegistered || '0' }} alunos inscritos</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import axios from 'axios';

const props = defineProps({
  shiftIds: {
    type: Array,
    default: () => []
  },
  showAll: {
    type: Boolean,
    default: false
  },
  yearFilter: {
    type: Array,
    default: () => []
  }
});

const shifts = ref([]);
const courses = ref({});
const classrooms = ref({});
const teachers = ref({});
const loading = ref(true);
const error = ref(null);
const celulasOcupadas = ref({});
const turnoSelecionado = ref(null);

const API_BASE_URL = 'http://localhost:3000';
const COURSES_URL = `${API_BASE_URL}/courses`;
const SHIFTS_URL = `${API_BASE_URL}/shifts`;
const CLASSROOMS_URL = `${API_BASE_URL}/classrooms`;
const TEACHERS_URL = `${API_BASE_URL}/teachers`;

const diasSemana = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira'];
const diasSemanaEn = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const horas = Array.from({ length: 12 }, (_, i) => i + 8); // 8h até 19h

const coresPorAno = {
  1: 'bg-1ano text-1anoTexto',
  2: 'bg-2ano text-2anoTexto',
  3: 'bg-3ano text-3anoTexto',
  4: 'bg-red text-white',
  5: 'bg-red text-white'
};

const fetchData = async () => {
  try {
    loading.value = true;
    console.log("Horario - Buscando dados com shiftIds:", props.shiftIds);

    const coursesResponse = await axios.get(COURSES_URL);
    const coursesData = coursesResponse.data;

    const coursesMap = coursesData.reduce((acc, course) => {
      acc[course.id] = course;
      return acc;
    }, {});

    courses.value = coursesMap;

    try {
      const classroomsResponse = await axios.get(CLASSROOMS_URL);
      const classroomsData = classroomsResponse.data;

      const classroomsMap = classroomsData.reduce((acc, classroom) => {
        acc[classroom.id] = classroom;
        return acc;
      }, {});

      classrooms.value = classroomsMap;
    } catch (err) {
      console.warn('Não foi possível carregar as salas de aula:', err);
    }
    
    try {
      const teachersResponse = await axios.get(TEACHERS_URL);
      const teachersData = teachersResponse.data;

      const teachersMap = teachersData.reduce((acc, teacher) => {
        acc[teacher.id] = teacher;
        return acc;
      }, {});

      teachers.value = teachersMap;
    } catch (err) {
      console.warn('Não foi possível carregar os professores:', err);
    }

    const shiftsResponse = await axios.get(SHIFTS_URL);
    let shiftsData = shiftsResponse.data;
    console.log("Total de turnos disponíveis:", shiftsData.length);

    if (props.shiftIds && props.shiftIds.length > 0 && !props.showAll) {
      const shiftIdsNumbers = props.shiftIds.map(id => Number(id));
      console.log("Filtrando por IDs (números):", shiftIdsNumbers);
      
      shiftsData = shiftsData.filter(shift => shiftIdsNumbers.includes(Number(shift.id)));
      console.log("Turnos filtrados:", shiftsData.length);
      console.log("IDs dos turnos filtrados:", shiftsData.map(s => s.id));
    }

    if (props.yearFilter && props.yearFilter.length > 0) {
      shiftsData = shiftsData.filter(shift => {
        const course = courses.value[shift.courseId.toString()];
        return course && props.yearFilter.includes(course.year);
      });
    }

    shifts.value = shiftsData;
    console.log("Turnos carregados no horário:", shifts.value.length);
    
    atualizarCelulasOcupadas();
    
    loading.value = false;
  } catch (err) {
    console.error('Erro ao buscar dados:', err);
    error.value = 'Erro ao carregar dados. Por favor, tente novamente.';
    loading.value = false;
  }
};

const atualizarCelulasOcupadas = () => {
  const ocupadas = {};
  
  diasSemanaEn.forEach((diaEn, diaIndex) => {
    const dia = diasSemana[diaIndex];
    
    horas.forEach(hora => {
      const turnosIniciando = getTurnosIniciandoEm(hora, dia);
      
      if (turnosIniciando.length > 0) {
        const turnoMaiorDuracao = turnosIniciando.reduce((prev, current) => 
          (current.to - current.from) > (prev.to - prev.from) ? current : prev
        );
        
        for (let h = hora + 1; h < turnoMaiorDuracao.to; h++) {
          ocupadas[`${h}-${dia}`] = true;
        }
      }
    });
  });
  
  celulasOcupadas.value = ocupadas;
};

watch(() => props.shiftIds, fetchData, { deep: true });
watch(() => props.showAll, fetchData);
watch(() => props.yearFilter, fetchData, { deep: true });

watch(() => props.shiftIds, (newVal) => {
  console.log("Horario - shiftIds alterado:", newVal);
  if (newVal) {
    fetchData();
  }
}, { deep: true, immediate: true });

const getCorPorAno = (courseId) => {
  const course = courses.value[courseId.toString()];
  if (!course) return 'bg-gray-600 text-white';
  return coresPorAno[course.year] || 'bg-gray-600 text-white';
};

const getCursoAbreviacao = (courseId) => {
  const course = courses.value[courseId.toString()];
  return course ? course.abbreviation : '';
};

const getCursoNome = (courseId) => {
  const course = courses.value[courseId.toString()];
  return course ? course.name : 'Curso Desconhecido';
};

const getAnoSemestre = (courseId) => {
  const course = courses.value[courseId.toString()];
  if (!course) return '';
  return `${course.year}º ano - ${course.semester}º sem`;
};

const getSalaInfo = (shift) => {
  const classroom = classrooms.value[shift.classroomId.toString()];
  const roomName = classroom ? classroom.name : `CP${shift.classroomId}`;
  return `Sala ${roomName}`;
};

const getSalaCompleta = (shift) => {
  const classroom = classrooms.value[shift.classroomId.toString()];
  const roomName = classroom ? classroom.name : `CP${shift.classroomId}`;
  return `Sala ${roomName}`;
};

const getProfessorNome = (teacherId) => {
  const teacher = teachers.value[teacherId.toString()];
  return teacher ? teacher.name : 'Professor não especificado';
};

const formatHorario = (turno) => {
  return `${turno.from}:00 - ${turno.to}:00`;
};

const getTurnosIniciandoEm = (hora, dia) => {
  const diaEn = diasSemanaEn[diasSemana.indexOf(dia)];
  const result = shifts.value.filter(shift => 
    shift.day === diaEn && 
    Number(shift.from) === Number(hora)
  );
  
  if (result.length > 0) {
    // console.log(`Encontrados ${result.length} turnos para ${dia} às ${hora}h`);
  }
  
  return result;
};

const getTurnosParaHoraDia = (hora, dia) => {
  const diaEn = diasSemanaEn[diasSemana.indexOf(dia)];
  return shifts.value.filter(shift => 
    shift.day === diaEn && 
    shift.from <= hora && 
    shift.to > hora
  );
};

const calcularRowspan = (turno) => {
  return turno.to - turno.from;
};

const abrirDetalhes = (turno) => {
  turnoSelecionado.value = turno;
};

const fecharDetalhes = () => {
  turnoSelecionado.value = null;
};

onMounted(fetchData);
</script>

<style scoped>
.horario-container table {
  table-layout: fixed;
  border-collapse: collapse;
  width: 100%;
}

.horario-container th,
.horario-container td {
  border: 1px solid black;
  padding: 0;
  position: relative;
}

.horario-container th {
  padding: 0.75rem;
  text-align: center;
  font-weight: 600;
}

.time-slot {
  height: 60px !important;
  min-height: 60px !important;
  position: relative;
}

.horario-container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
}

.fundo-escuro {
  background-color: rgba(0, 0, 0, 0.25);
}
</style>
