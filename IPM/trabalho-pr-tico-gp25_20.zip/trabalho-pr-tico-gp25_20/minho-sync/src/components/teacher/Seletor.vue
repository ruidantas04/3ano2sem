<template>
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
      <div class="p-4 border-b border-gray-200">
        <h3 class="text-xl font-semibold text-gray-800">Turnos Inscritos</h3>
      </div>
      
      <div v-if="loading" class="p-8 text-center text-gray-500">
        Carregando turnos...
      </div>
      
      <div v-else-if="error" class="p-8 text-center text-red-500">
        {{ error }}
      </div>
      
      <div v-else class="p-0">
        <div v-for="(cursoTurnos, index) in turnosPorCurso" :key="index" class="border-b border-gray-200">
          <div 
            class="flex items-center p-4 hover:bg-gray-50 cursor-pointer"
            @click="toggleCurso(cursoTurnos.curso.id)"
          >
            <span class="mr-2">
              <svg v-if="expandedCourses.includes(cursoTurnos.curso.id)" 
                   xmlns="http://www.w3.org/2000/svg" 
                   width="20" height="20" 
                   viewBox="0 0 24 24" 
                   fill="none" 
                   stroke="currentColor" 
                   stroke-width="2" 
                   stroke-linecap="round" 
                   stroke-linejoin="round" 
                   class="text-gray-500">
                <path d="m18 15-6-6-6 6"/>
              </svg>
              <svg v-else 
                   xmlns="http://www.w3.org/2000/svg" 
                   width="20" height="20" 
                   viewBox="0 0 24 24" 
                   fill="none" 
                   stroke="currentColor" 
                   stroke-width="2" 
                   stroke-linecap="round" 
                   stroke-linejoin="round" 
                   class="text-gray-500">
                <path d="m9 18 6-6-6-6"/>
              </svg>
            </span>
            <span class="font-medium">{{ cursoTurnos.curso.abbreviation }}</span>
          </div>
          
          <div v-if="expandedCourses.includes(cursoTurnos.curso.id)" class="pl-10 pr-4 pb-4">
            <div 
              v-for="turno in cursoTurnos.turnos" 
              :key="turno.id"
              class="flex items-center"
            >
              <div 
                class="w-3 h-3 rounded-full mr-3"
                :class="selectedShifts.includes(turno.id) ? 'bg-red' : 'bg-gray'"
                @click="toggleShift(turno.id)"
              ></div>
              <span>{{ turno.name }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, computed, onMounted, watch } from 'vue';
  import axios from 'axios';
  
  const props = defineProps({
    teacherId: {
      type: String,
      required: true
    }
  });
  
  const emit = defineEmits(['selection-change']);
  
  const shifts = ref([]);
  const courses = ref([]);
  const loading = ref(true);
  const error = ref(null);
  const expandedCourses = ref([]);
  const selectedShifts = ref([]);
  
  const API_BASE_URL = 'http://localhost:3000';
  const COURSES_URL = `${API_BASE_URL}/courses`;
  const SHIFTS_URL = `${API_BASE_URL}/shifts`;
  
  const fetchData = async () => {
    try {
      loading.value = true;
  
      const coursesResponse = await axios.get(COURSES_URL);
      courses.value = coursesResponse.data;
  
      const shiftsResponse = await axios.get(SHIFTS_URL);
      const teacherShifts = shiftsResponse.data.filter(shift => 
        shift.teacherId.toString() === props.teacherId.toString()
      );
      
      shifts.value = teacherShifts;
      
      selectedShifts.value = teacherShifts.map(shift => shift.id);
      
      emit('selection-change', selectedShifts.value);
      
      if (turnosPorCurso.value.length > 0) {
        expandedCourses.value = [turnosPorCurso.value[0].curso.id];
      }
      
      loading.value = false;
    } catch (err) {
      console.error('Erro ao buscar dados:', err);
      error.value = 'Erro ao carregar dados. Por favor, tente novamente.';
      loading.value = false;
    }
  };
  
    const resultado = [];
    const cursoIds = new Set(shifts.value.map(shift => shift.courseId));
    
    cursoIds.forEach(cursoId => {
      const curso = courses.value.find(c => c.id.toString() === cursoId.toString());
      if (curso) {
        const turnosDoCurso = shifts.value.filter(shift => 
          shift.courseId.toString() === cursoId.toString()
        );
        
        resultado.push({
          curso,
          turnos: turnosDoCurso
        });
      }
    });
    
    return resultado.sort((a, b) => 
      a.curso.abbreviation.localeCompare(b.curso.abbreviation)
    );
  });
  
  const toggleCurso = (cursoId) => {
    if (expandedCourses.value.includes(cursoId)) {
      expandedCourses.value = expandedCourses.value.filter(id => id !== cursoId);
    } else {
      expandedCourses.value.push(cursoId);
    }
  };
  
 
  
  onMounted(fetchData);
  </script>