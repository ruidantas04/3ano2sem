<template>
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
      <div v-if="loading" class="p-6 text-center text-gray-500">
        Carregando turnos...
      </div>
      
      <div v-else-if="error" class="p-6 text-center text-red-500">
        {{ error }}
      </div>
      
      <div v-else class="p-4">
        <div class="space-y-2">
          <div 
            v-for="ano in anos" 
            :key="`ano-${ano}`" 
            class="mb-2"
          >
            <div 
              class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer"
              @click="toggleYear(ano)"
            >
              <span class="mr-2 w-4 text-center text-xs">
                {{ expandedYears.includes(ano) ? '▼' : '▶' }}
              </span>
              <span class="font-semibold">{{ ano }}º ano</span>
              <span 
                v-if="getYearIndicator(ano)" 
                class="ml-auto w-2 h-2 rounded-full"
                :class="isYearSelected(ano) ? 'bg-red' : 'bg-gray-200'"
              ></span>
            </div>
            
            <div v-if="expandedYears.includes(ano)" class="ml-6 mt-2">
              <div 
                v-for="semestre in semestres" 
                :key="`${ano}-${semestre}`"
                class="mb-2"
              >
                <div 
                  class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer"
                  @click="toggleSemester(ano, semestre)"
                >
                  <span class="mr-2 w-4 text-center text-xs">
                    {{ expandedSemesters.includes(`${ano}-${semestre}`) ? '▼' : '▶' }}
                  </span>
                  <span class="font-medium">{{ semestre }}º semestre</span>
                  
                </div>
                
                <div v-if="expandedSemesters.includes(`${ano}-${semestre}`)" class="ml-6 mt-2">
                  <div 
                    v-for="curso in getCursosPorAnoSemestre(ano, semestre)" 
                    :key="`curso-${curso.id}`"
                    class="mb-2"
                  >
                    <div 
                      class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer"
                      @click="toggleCourse(curso.id)"
                    >
                      <span class="mr-2 w-4 text-center text-xs">
                        {{ expandedCourses.includes(curso.id) ? '▼' : '▶' }}
                      </span>
                      <span class="font-medium">{{ curso.abbreviation }}</span>
                      <span 
                        v-if="getCourseIndicator(curso.id)" 
                        class="ml-auto w-2 h-2 rounded-full"
                        :class="isCourseSelected(curso.id) ? 'bg-red' : 'bg-gray-200'"
                      ></span>
                    </div>
                    
                    <div v-if="expandedCourses.includes(curso.id)" class="ml-6 mt-2">
                      <div class="mb-2 pb-2 border-b border-gray-200">
                        <label class="flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            class="form-checkbox h-4 w-4 text-red"
                            :checked="isCourseFullySelected(curso.id)"
                            :indeterminate.prop="isCoursePartiallySelected(curso.id)"
                            @change="toggleAllTurnosCurso(curso.id)"
                          />
                          <span class="ml-2 font-medium">Selecionar Todos</span>
                        </label>
                      </div>
                      
                      <div 
                        v-for="turno in getTurnosPorCurso(curso.id)" 
                        :key="`turno-${turno.id}`"
                        class="mb-1"
                      >
                        <label class="flex items-center p-1 cursor-pointer hover:bg-gray-50 rounded">
                          <input 
                            type="checkbox" 
                            class="form-checkbox h-4 w-4 text-blue-500"
                            :checked="selectedShifts.includes(turno.id)"
                            @change="toggleShift(turno.id)"
                          />
                          <span class="ml-2">
                            {{ turno.name }} - {{ getDiaSemana(turno.day) }}, {{ turno.from }}h-{{ turno.to }}h
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
import { ref, computed, onMounted, watch } from "vue"
import axios from "axios"

const emit = defineEmits(["selection-change"])

const props = defineProps({
  initialSelection: {
    type: Array,
    default: () => [],
  },
})

const shifts = ref([])
const courses = ref([])
const loading = ref(true)
const error = ref(null)
const selectedShifts = ref([...props.initialSelection])

const API_BASE_URL = "http://localhost:3000"
const COURSES_URL = `${API_BASE_URL}/courses`
const SHIFTS_URL = `${API_BASE_URL}/shifts`

const expandedYears = ref([])
const expandedSemesters = ref([])
const expandedCourses = ref([])

const anos = [1, 2, 3]
const semestres = [1, 2]

const diasSemana = {
  Monday: "Segunda-feira",
  Tuesday: "Terça-feira",
  Wednesday: "Quarta-feira",
  Thursday: "Quinta-feira",
  Friday: "Sexta-feira",
}

const fetchData = async () => {
  try {
    loading.value = true

    const coursesResponse = await axios.get(COURSES_URL)
    courses.value = coursesResponse.data

    const shiftsResponse = await axios.get(SHIFTS_URL)
    shifts.value = shiftsResponse.data

    loading.value = false
  } catch (err) {
    console.error("Erro ao buscar dados:", err)
    error.value = "Erro ao carregar dados. Por favor, tente novamente."
    loading.value = false
  }
}

const getCursosPorAnoSemestre = (ano, semestre) => {
  return courses.value.filter((course) => course.year === ano && course.semester === semestre)
}

const getTurnosPorCurso = (courseId) => {
  return shifts.value.filter((shift) => shift.courseId.toString() === courseId.toString())
}

const getCourseIndicator = (courseId) => {
  const turnosCurso = getTurnosPorCurso(courseId)
  return turnosCurso.length > 0
}

const getYearIndicator = (ano) => {
  return courses.value.some((course) => course.year === ano)
}

const isCourseFullySelected = (courseId) => {
  const turnosCurso = getTurnosPorCurso(courseId)
  return turnosCurso.length > 0 && turnosCurso.every((turno) => selectedShifts.value.includes(turno.id))
}

const isCoursePartiallySelected = (courseId) => {
  const turnosCurso = getTurnosPorCurso(courseId)
  const selectedCount = turnosCurso.filter((turno) => selectedShifts.value.includes(turno.id)).length
  return selectedCount > 0 && selectedCount < turnosCurso.length
}

const isCourseSelected = (courseId) => {
  return getTurnosPorCurso(courseId).some((turno) => selectedShifts.value.includes(turno.id))
}

const isYearSelected = (ano) => {
  const cursosDessaAno = courses.value.filter((course) => course.year === ano)
  return cursosDessaAno.some((curso) => isCourseSelected(curso.id))
}

const getDiaSemana = (dia) => {
  return diasSemana[dia] || dia
}

const toggleYear = (ano) => {
  if (expandedYears.value.includes(ano)) {
    expandedYears.value = expandedYears.value.filter((y) => y !== ano)
  } else {
    expandedYears.value.push(ano)
  }
}

const toggleSemester = (ano, semestre) => {
  const key = `${ano}-${semestre}`
  if (expandedSemesters.value.includes(key)) {
    expandedSemesters.value = expandedSemesters.value.filter((s) => s !== key)
  } else {
    expandedSemesters.value.push(key)
  }
}

const toggleCourse = (courseId) => {
  if (expandedCourses.value.includes(courseId)) {
    expandedCourses.value = expandedCourses.value.filter((c) => c !== courseId)
  } else {
    expandedCourses.value.push(courseId)
  }
}

const toggleShift = (shiftId) => {
  if (selectedShifts.value.includes(shiftId)) {
    selectedShifts.value = selectedShifts.value.filter((id) => id !== shiftId)
  } else {
    selectedShifts.value.push(shiftId)
  }

  emit("selection-change", selectedShifts.value)
}

const toggleAllTurnosCurso = (courseId) => {
  const turnosCurso = getTurnosPorCurso(courseId)
  const allSelected = isCourseFullySelected(courseId)

  if (allSelected) {
    selectedShifts.value = selectedShifts.value.filter((id) => !turnosCurso.some((turno) => turno.id === id))
  } else {
    const turnosIds = turnosCurso.map((turno) => turno.id)
    const currentSelected = new Set(selectedShifts.value)
    turnosIds.forEach((id) => currentSelected.add(id))
    selectedShifts.value = Array.from(currentSelected)
  }

  emit("selection-change", selectedShifts.value)
}

watch(
  () => props.initialSelection,
  (newVal) => {
    if (newVal && newVal.length > 0) {
      selectedShifts.value = [...newVal]
    }
  },
  { deep: true, immediate: true },
)

onMounted(fetchData)

  </script>