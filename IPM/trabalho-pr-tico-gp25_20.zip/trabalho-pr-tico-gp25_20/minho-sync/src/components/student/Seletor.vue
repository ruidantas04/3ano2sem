<template>
  <div class="bg-white rounded-lg shadow-md overflow-hidden">
    <div class="p-4 border-b border-gray-200">
      <h3 class="text-xl font-semibold text-gray-800">Turnos Inscritos</h3>
    </div>
    
    <div v-if="loading" class="p-8 text-center text-gray-500">
      Carregando turnos...
    </div>
    
    <div v-else-if="error" class="p-8 text-center text-red-500">
      {{ error }}
    </div>
    
    <div v-else-if="turnosPorCurso.length === 0" class="p-8 text-center text-gray-500">
      Nenhum turno encontrado. Verifique se você está inscrito em algum turno.
    </div>
    
    <div v-else class="p-0">
      <div v-for="(cursoTurnos, index) in turnosPorCurso" :key="index" class="border-b border-gray-200">
        <div 
          class="flex items-center p-4 hover:bg-gray-50 cursor-pointer"
          @click="toggleCurso(cursoTurnos.curso.id)"
        >
          <span class="mr-2">
            <svg v-if="expandedCourses.includes(cursoTurnos.curso.id)" 
                 xmlns="http://www.w3.org/2000/svg" 
                 width="20" height="20" 
                 viewBox="0 0 24 24" 
                 fill="none" 
                 stroke="currentColor" 
                 stroke-width="2" 
                 stroke-linecap="round" 
                 stroke-linejoin="round" 
                 class="text-gray-500">
              <path d="m18 15-6-6-6 6"/>
            </svg>
            <svg v-else 
                 xmlns="http://www.w3.org/2000/svg" 
                 width="20" height="20" 
                 viewBox="0 0 24 24" 
                 fill="none" 
                 stroke="currentColor" 
                 stroke-width="2" 
                 stroke-linecap="round" 
                 stroke-linejoin="round" 
                 class="text-gray-500">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </span>
          <span class="font-medium">{{ cursoTurnos.curso.abbreviation }}</span>
        </div>
        
        <div v-if="expandedCourses.includes(cursoTurnos.curso.id)" class="pl-10 pr-4 pb-4">
          <div 
            v-for="turno in cursoTurnos.turnos" 
            :key="turno.id"
            class="flex items-center py-1"
          >
            <div 
              class="w-3 h-3 rounded-full mr-3 cursor-pointer bg-red"
            ></div>
            <span>{{ turno.name }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import axios from 'axios';

const props = defineProps({
  studentId: {
    type: [String, Number],
    default: '1'
  }
});

const emit = defineEmits(['selection-change']);

const shifts = ref([]);
const courses = ref([]);
const loading = ref(true);
const error = ref(null);
const expandedCourses = ref([]);
const selectedShifts = ref([]);

// URLs do JSON Server
const API_BASE_URL = 'http://localhost:3000';
const COURSES_URL = `${API_BASE_URL}/courses`;
const SHIFTS_URL = `${API_BASE_URL}/shifts`;
const STUDENTS_URL = `${API_BASE_URL}/students`;
const ALLOCATIONS_URL = `${API_BASE_URL}/allocations`;

// Buscar dados
const fetchData = async () => {
  try {
    loading.value = true;
    console.log("Buscando dados para o aluno ID:", props.studentId);

    // Buscar cursos
    const coursesResponse = await axios.get(COURSES_URL);
    courses.value = coursesResponse.data;
    console.log("Cursos carregados:", courses.value.length);

    // Buscar dados do aluno
    const studentResponse = await axios.get(`${STUDENTS_URL}/${props.studentId}`);
    const studentData = studentResponse.data;
    console.log("Dados do aluno:", studentData);

    // Buscar todos os turnos
    const shiftsResponse = await axios.get(SHIFTS_URL);
    const allShifts = shiftsResponse.data;
    console.log("Total de turnos disponíveis:", allShifts.length);

    const allocationsResponse = await axios.get(`${ALLOCATIONS_URL}?studentId=${props.studentId}`)
    const studentAllocations = allocationsResponse.data
    console.log("Alocações do aluno:", studentAllocations)

    // Obter os IDs dos turnos em que o aluno está inscrito
    const enrolledShiftIds = studentData.enrolled || [];
    console.log("Turnos inscritos do aluno:", enrolledShiftIds);
    
    
    // Filtrar os turnos - garantindo que os IDs sejam comparados como strings
    shifts.value = allShifts.filter(shift => 
      enrolledShiftIds.includes(parseInt(shift.courseId))
    )
    console.log("Turnos disponíveis para o aluno:", shifts.value.length)

    
    console.log("Turnos filtrados:", shifts.value.length);
    
      // Selecionar automaticamente os turnos em que o aluno já está alocado
    if (studentAllocations && studentAllocations.length > 0) {
      selectedShifts.value = studentAllocations.map(allocation => allocation.shiftId)
      console.log("Turnos selecionados:", selectedShifts.value)
      emit('selection-change', selectedShifts.value)
    }
    // Expandir o primeiro curso por padrão (se houver)
    if (turnosPorCurso.value.length > 0) {
      expandedCourses.value = [turnosPorCurso.value[0].curso.id];
    }
    
    loading.value = false;
  } catch (err) {
    console.error('Erro ao buscar dados:', err);
    error.value = `Erro ao carregar dados: ${err.message}. Por favor, tente novamente.`;
    loading.value = false;
  }
};

// Agrupar turnos por curso
const turnosPorCurso = computed(() => {
  const resultado = [];
  
  // Criar um Set com os IDs dos cursos (convertidos para string para segurança)
  const cursoIds = new Set(shifts.value.map(shift => String(shift.courseId)));
  
  // Iterar sobre os IDs dos cursos
  cursoIds.forEach(cursoIdStr => {
    // Encontrar o curso correspondente
    const curso = courses.value.find(c => String(c.id) === cursoIdStr);
    
    if (curso) {
      // Filtrar os turnos deste curso
      const turnosDoCurso = shifts.value.filter(shift => 
        String(shift.courseId) === cursoIdStr
      );
      
      resultado.push({
        curso,
        turnos: turnosDoCurso
      });
    }
  });
  
  // Ordenar por abreviação do curso
  return resultado.sort((a, b) => 
    a.curso.abbreviation.localeCompare(b.curso.abbreviation)
  );
});

// Toggle de curso (expandir/colapsar)
const toggleCurso = (cursoId) => {
  if (expandedCourses.value.includes(cursoId)) {
    expandedCourses.value = expandedCourses.value.filter(id => id !== cursoId);
  } else {
    expandedCourses.value.push(cursoId);
  }
};

// Toggle de turno (selecionar/deselecionar)
const toggleShift = (shiftId) => {
  if (selectedShifts.value.includes(shiftId)) {
    selectedShifts.value = selectedShifts.value.filter(id => id !== shiftId);
  } else {
    selectedShifts.value.push(shiftId);
  }
  
  emit('selection-change', selectedShifts.value);
};

// Carregar dados ao montar o componente
onMounted(fetchData);

// Observar mudanças no studentId
watch(() => props.studentId, (newVal) => {
  if (newVal) {
    fetchData();
  }
});
</script>