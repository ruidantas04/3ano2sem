<template>
  <div class="overflow-hidden">
    <div class="p-3 border-b border-gray-200">
      <h3 class="font-semibold text-gray-800">Ocupação atual dos turnos selecionados:</h3>
    </div>
    
    <div v-if="loading" class="p-8 text-center text-gray-500">
      <div class="flex justify-center">
        <svg class="animate-spin h-8 w-8 text-red-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
      <p class="mt-2">Carregando turnos...</p>
    </div>
    
    <div v-else-if="error" class="p-8 text-center text-red-500">
      {{ error }}
    </div>
    
    <div v-else class="overflow-y-auto max-h-[calc(100vh-150px)]">
      <!-- Lista de turnos com ocupação -->
      <div class="p-2 space-y-2">
        <div 
          v-for="turno in turnosSelecionados" 
          :key="turno.id"
          class="p-4 rounded-md transition-all duration-200 hover:brightness-95"
          :class="getBackgroundColorByType(turno.courseId)"
        >
          <div class="flex justify-between items-center mb-1">
            <div class="font-medium"
            :class="getCorTextByYear(turno.courseId)">{{ getTurnoNome(turno) }}</div>
            <div class="text-sm font-medium">
              {{ turno.ocupacao.percentual }}% {{ turno.ocupacao.atual }}/{{ turno.ocupacao.total }}
            </div>
          </div>
          
          <div class="w-full bg-white bg-opacity-50 rounded-full h-2.5 mb-1">
            <div 
              class="h-2.5 rounded-full" 
              :class="getProgressBarColor(turno.ocupacao.percentual)"
              :style="{ width: `${turno.ocupacao.percentual}%` }"
            ></div>
          </div>
        </div>
      </div>
      
      <!-- Mensagem quando não há turnos selecionados -->
      <div v-if="turnosSelecionados.length === 0" class="text-center py-8 text-gray-500">
        Nenhum turno selecionado. Selecione turnos no horário.
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from "vue"
import axios from "axios"

const props = defineProps({
  shiftIds: {
    type: Array,
    default: () => [],
  },
})

const emit = defineEmits(["selection-change"])

const shifts = ref([])
const courses = ref({})
const classrooms = ref({})
const allocations = ref([])
const loading = ref(true)
const error = ref(null)
const selectedShifts = ref([...props.shiftIds])

const API_BASE_URL = "http://localhost:3000"
const COURSES_URL = `${API_BASE_URL}/courses`
const SHIFTS_URL = `${API_BASE_URL}/shifts`
const CLASSROOMS_URL = `${API_BASE_URL}/classrooms`
const ALLOCATIONS_URL = `${API_BASE_URL}/allocations`

const fetchData = async () => {
  try {
    loading.value = true

    const coursesResponse = await axios.get(COURSES_URL)
    const coursesData = coursesResponse.data

    const coursesMap = coursesData.reduce((acc, course) => {
      acc[course.id] = course
      return acc
    }, {})

    courses.value = coursesMap

    try {
      const classroomsResponse = await axios.get(CLASSROOMS_URL)
      const classroomsData = classroomsResponse.data

      const classroomsMap = classroomsData.reduce((acc, classroom) => {
        acc[classroom.id] = classroom
        return acc
      }, {})

      classrooms.value = classroomsMap
    } catch (err) {
      console.warn("Não foi possível carregar as salas de aula:", err)
    }

    try {
      const allocationsResponse = await axios.get(ALLOCATIONS_URL)
      allocations.value = allocationsResponse.data
      console.log("Alocações carregadas:", allocations.value.length)
    } catch (err) {
      console.error("Não foi possível carregar as alocações:", err)
      allocations.value = []
    }

    const shiftsResponse = await axios.get(SHIFTS_URL)
    const shiftsData = shiftsResponse.data

    shifts.value = shiftsData.map((shift) => {
      const classroom = classrooms.value[shift.classroomId]
      const maxCapacity = classroom ? classroom.capacity : 30

      const shiftIdNumber = Number(shift.id)
      const alunosAlocados = allocations.value.filter(
        (allocation) => Number(allocation.shiftId) === shiftIdNumber,
      ).length

      console.log(`Turno ${shift.id} (${shift.name}): ${alunosAlocados} alunos de ${maxCapacity} vagas`)

      const percentual = maxCapacity > 0 ? Math.round((alunosAlocados / maxCapacity) * 100) : 0

      return {
        ...shift,
        ocupacao: {
          total: maxCapacity,
          atual: alunosAlocados,
          percentual: percentual,
        },
      }
    })

    loading.value = false
  } catch (err) {
    console.error("Erro ao buscar dados:", err)
    error.value = "Erro ao carregar dados. Por favor, tente novamente."
    loading.value = false
  }
}

const turnosSelecionados = computed(() => {
  return shifts.value
    .filter((shift) => selectedShifts.value.includes(shift.id))
    .sort((a, b) => {
      const cursoA = courses.value[a.courseId]?.abbreviation || ""
      const cursoB = courses.value[b.courseId]?.abbreviation || ""

      if (cursoA !== cursoB) {
        return cursoA.localeCompare(cursoB)
      }

      return a.name.localeCompare(b.name)
    })
})

const getTurnoNome = (turno) => {
  const curso = courses.value[turno.courseId]
  const abreviacao = curso ? curso.abbreviation : "CP"

  return `${abreviacao} - ${turno.name}`
}

const getBackgroundColorByType = (courseId) => {
  const curso = courses.value[courseId]
  if (!curso) return "bg-red-100"

  const ano = curso.year

  if (ano === 1) return "bg-1ano "
  if (ano === 2) return "bg-2ano"
  if (ano === 3) return "bg-3ano"

  return "bg-red"
}

const getCorTextByYear = (courseId) => {
  const curso = courses.value[courseId]
  if (!curso) return "bg-red-100"

  const ano = curso.year

  if (ano === 1) return "text-1anoTexto"
  if (ano === 2) return "text-2anoTexto"
  if (ano === 3) return "text-3anoTexto"

  return "bg-red"
}

const getProgressBarColor = (percentual) => {
  if (percentual >= 90) return "bg-red-600" 
  if (percentual >= 50) return "bg-yellow-500" 
  return "bg-green-500" 
}

watch(
  () => props.shiftIds,
  (newVal) => {
    selectedShifts.value = [...newVal]
  },
  { deep: true },
)

onMounted(fetchData)

</script>
