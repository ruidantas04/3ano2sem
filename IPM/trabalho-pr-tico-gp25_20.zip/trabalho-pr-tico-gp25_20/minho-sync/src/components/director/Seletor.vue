<template>
  <div class="overflow-hidden">
    <div class="py-1 flex justify-end items-center">
      <button 
        @click="goBack" 
        class="text-gray-700 px-3 py-1 rounded-md flex items-center"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
      </button>
    </div>

    <div v-if="loading" class="p-6 text-center text-gray-500">
      Carregando turnos...
    </div>
    
    <div v-else-if="error" class="p-6 text-center text-red-500">
      {{ error }}
    </div>
    
    <div v-else>
      <div class="p-4 bg-white rounded-lg shadow-md mb-4">
        <div class="mb-2">
          <p class="text-sm font-medium">Nome:</p>
          <p class="text-gray-500 font-medium">{{ student?.name || 'Carregando...' }}</p>
        </div>
        <div class="mb-2">
          <p class="text-sm font-medium">Número:</p>
          <p class="text-gray-500 font-medium">{{ student?.mecanographicNumber || 'Carregando...' }}</p>
        </div>
        <div>
          <p class="text-sm font-medium">Estatuto:</p>
          <p class="text-gray-500 ont-medium">{{ student?.specialStatus ? 'Especial' : 'Regular' }}</p>
        </div>
        <button 
          @click="verPerfil" 
          class="w-full bg-red hover:bg-dark-red cursor-pointer text-white py-2 mt-2 px-4 rounded-md font-medium"
          :disabled="loading"
        >
          Ver Perfil
        </button>
      </div>

      <div class="p-4 bg-white rounded-lg shadow-md mb-4">
        <h2 class="text-lg font-medium mb-2">UCs Inscritos</h2>
        <div v-if="turnosPorCurso.length === 0" class="text-center py-4 text-gray-500">
          Nenhuma UC inscrita encontrada.
        </div>
        
        <div v-else class="space-y-2 ml-1">
          <div 
            v-for="cursoTurnos in turnosPorCurso" 
            :key="`course-${cursoTurnos.curso.id}`"
            class="mb-2"
          >
            <div 
              class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer"
              @click="toggleCourse(cursoTurnos.curso.id)"
            >
              <span class="mr-1 w-4 text-center text-xs">
                {{ expandedCourses.includes(cursoTurnos.curso.id) ? '▼' : '▶' }}
              </span>
              <span class="font-medium">{{ cursoTurnos.curso.abbreviation }} - {{ cursoTurnos.curso.name }}</span>
              <span 
                v-if="cursoTurnos.turnos.length > 0" 
                class="ml-auto w-2 h-2 rounded-full"
                :class="isCourseSelected(cursoTurnos.curso.id) ? 'bg-red-500' : 'bg-gray-200'"
              ></span>
            </div>
            
            <div v-if="expandedCourses.includes(cursoTurnos.curso.id)" class="ml-6 mt-2">
              <div class="mb-2 pb-2 border-b border-gray-200">
                <label class="flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    class="form-checkbox h-4 w-4 text-red-500"
                    :checked="isCourseFullySelected(cursoTurnos.curso.id)"
                    :indeterminate="isCoursePartiallySelected(cursoTurnos.curso.id)"
                    @change="toggleAllTurnosCurso(cursoTurnos.curso.id)"
                  />
                  <span class="ml-2 font-medium">Selecionar Todos</span>
                </label>
              </div>
              
              <div 
                v-for="turno in cursoTurnos.turnos" 
                :key="`turno-${turno.id}`"
                class="mb-1"
              >
                <label class="flex items-center p-1 cursor-pointer hover:bg-gray-50 rounded">
                  <input 
                    type="checkbox" 
                    class="form-checkbox h-4 w-4 text-red-500"
                    :checked="selectedShifts.includes(turno.id)"
                    @change="toggleShift(turno.id)"
                  />
                  <span class="ml-2">
                    {{ turno.name }} - {{ getDiaSemana(turno.day) }}, {{ turno.from }}h-{{ turno.to }}h
                  </span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="border-t border-gray-200">
        <button  v-if="conflitos.length == 0"
          @click="publicarHorario" 
          class="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-md font-medium"
          :disabled="loading"
        >
          Publicar Horário
        </button>
        
        <div v-if="conflitos.length > 0" class="mt-3 p-3 bg-red-50 border border-red-200 rounded-md">
          <div class="flex items-center text-red-600 mb-1">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <span class="font-medium">{{ conflitos.length }} Turnos com conflito</span>
          </div>
          <ul class="text-sm text-red-600 ml-6 list-disc">
            <li v-for="(conflito, index) in conflitos" :key="index">
              {{ getConflictDescription(conflito) }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
  
<script setup>
import { ref, computed, onMounted, watch } from "vue"
import axios from "axios"
import { useRouter } from "vue-router"

const emit = defineEmits(["selection-change"])

const props = defineProps({
  studentId: {
    type: [String, Number],
    required: true
  },
  initialSelection: {
    type: Array,
    default: () => [],
  },
})

const router = useRouter()
const shifts = ref([])
const courses = ref([])
const student = ref(null)
const loading = ref(true)
const error = ref(null)
const selectedShifts = ref([])
const conflitos = ref([])

const API_BASE_URL = "http://localhost:3000"
const COURSES_URL = `${API_BASE_URL}/courses`
const SHIFTS_URL = `${API_BASE_URL}/shifts`
const STUDENTS_URL = `${API_BASE_URL}/students`
const ALLOCATIONS_URL = `${API_BASE_URL}/allocations`

const expandedCourses = ref([])

const diasSemana = {
  Monday: "Segunda-feira",
  Tuesday: "Terça-feira",
  Wednesday: "Quarta-feira",
  Thursday: "Quinta-feira",
  Friday: "Sexta-feira",
}

const fetchData = async () => {
  try {
    loading.value = true
    console.log("Buscando dados para o aluno ID:", props.studentId)

    const studentResponse = await axios.get(`${STUDENTS_URL}/${props.studentId}`)
    student.value = studentResponse.data
    console.log("Dados do aluno:", student.value)

    if (!student.value || !student.value.enrolled || !Array.isArray(student.value.enrolled)) {
      throw new Error("Dados do aluno inválidos ou aluno não tem UCs inscritas")
    }

    const coursesResponse = await axios.get(COURSES_URL)
    const allCourses = coursesResponse.data
    console.log("Total de cursos:", allCourses.length)

    courses.value = allCourses.filter(course => 
      student.value.enrolled.includes(parseInt(course.id))
    )
    console.log("Cursos inscritos:", courses.value.length)

    const shiftsResponse = await axios.get(SHIFTS_URL)
    const allShifts = shiftsResponse.data
    console.log("Total de turnos:", allShifts.length)

    const allocationsResponse = await axios.get(`${ALLOCATIONS_URL}?studentId=${props.studentId}`)
    const studentAllocations = allocationsResponse.data
    console.log("Alocações do aluno:", studentAllocations)

    shifts.value = allShifts.filter(shift => 
      student.value.enrolled.includes(parseInt(shift.courseId))
    )
    console.log("Turnos disponíveis para o aluno:", shifts.value.length)

    if (studentAllocations && studentAllocations.length > 0) {
      selectedShifts.value = studentAllocations.map(allocation => allocation.shiftId)
      console.log("Turnos selecionados:", selectedShifts.value)
      emit('selection-change', selectedShifts.value)
    }

    verificarConflitos()

    expandSelectedCourses()

    loading.value = false
  } catch (err) {
    console.error("Erro ao buscar dados:", err)
    error.value = "Erro ao carregar dados. Por favor, tente novamente."
    loading.value = false
  }
}

const turnosPorCurso = computed(() => {
  const resultado = []
  
  const cursoIds = new Set(shifts.value.map(shift => String(shift.courseId)))
  
  cursoIds.forEach(cursoIdStr => {
    const curso = courses.value.find(c => String(c.id) === cursoIdStr)
    
    if (curso) {
      const turnosDoCurso = shifts.value.filter(shift => 
        String(shift.courseId) === cursoIdStr
      )
      
      resultado.push({
        curso,
        turnos: turnosDoCurso
      })
    }
  })
  
  return resultado.sort((a, b) => 
    a.curso.abbreviation.localeCompare(b.curso.abbreviation)
  )
})

const expandSelectedCourses = () => {
  turnosPorCurso.value.forEach(cursoTurnos => {
    const hasSelectedShifts = cursoTurnos.turnos.some(turno => 
      selectedShifts.value.includes(turno.id)
    )
    
    if (hasSelectedShifts && !expandedCourses.value.includes(cursoTurnos.curso.id)) {
      expandedCourses.value.push(cursoTurnos.curso.id)
    }
  })
}

const verificarConflitos = () => {
  const conflitosEncontrados = []
  const turnosSelecionados = shifts.value.filter(shift => selectedShifts.value.includes(shift.id))
  
  const turnosPorDia = {}
  
  turnosSelecionados.forEach(turno => {
    if (!turnosPorDia[turno.day]) {
      turnosPorDia[turno.day] = []
    }
    turnosPorDia[turno.day].push(turno)
  })
  
  Object.keys(turnosPorDia).forEach(dia => {
    const turnosNoDia = turnosPorDia[dia]
    
    for (let i = 0; i < turnosNoDia.length; i++) {
      for (let j = i + 1; j < turnosNoDia.length; j++) {
        const turno1 = turnosNoDia[i]
        const turno2 = turnosNoDia[j]
        
        if (
          (turno1.from < turno2.to && turno1.to > turno2.from)
        ) {
          conflitosEncontrados.push({
            turno1,
            turno2,
            dia
          })
        }
      }
    }
  })
  
  conflitos.value = conflitosEncontrados
}

const isCourseFullySelected = (courseId) => {
  const cursoTurnos = turnosPorCurso.value.find(ct => ct.curso.id === courseId);
  if (!cursoTurnos) return false;
  
  return cursoTurnos.turnos.length > 0 && 
         cursoTurnos.turnos.every(turno => 
           selectedShifts.value.includes(Number(turno.id))
         );
}

const isCoursePartiallySelected = (courseId) => {
  const cursoTurnos = turnosPorCurso.value.find(ct => ct.curso.id === courseId);
  if (!cursoTurnos) return false;
  
  const selectedCount = cursoTurnos.turnos.filter(turno => 
    selectedShifts.value.includes(Number(turno.id))
  ).length;
  
  return selectedCount > 0 && selectedCount < cursoTurnos.turnos.length;
}

const isCourseSelected = (courseId) => {
  const cursoTurnos = turnosPorCurso.value.find(ct => ct.curso.id === courseId);
  if (!cursoTurnos) return false;
  
  return cursoTurnos.turnos.some(turno => 
    selectedShifts.value.includes(Number(turno.id))
  );
}

const getDiaSemana = (dia) => {
  return diasSemana[dia] || dia
}

const toggleCourse = (courseId) => {
  if (expandedCourses.value.includes(courseId)) {
    expandedCourses.value = expandedCourses.value.filter((c) => c !== courseId)
  } else {
    expandedCourses.value.push(courseId)
  }
}

const toggleShift = (shiftId) => {
  const numericId = Number(shiftId);
  
  if (selectedShifts.value.includes(numericId)) {
    selectedShifts.value = selectedShifts.value.filter(id => id !== numericId);
  } else {
    selectedShifts.value.push(numericId);
  }

  verificarConflitos();
  
  const normalizedShifts = [...selectedShifts.value].map(id => Number(id));
  console.log("Emitindo seleção:", normalizedShifts);
  emit("selection-change", normalizedShifts);
}

const toggleAllTurnosCurso = (courseId) => {
  const cursoTurnos = turnosPorCurso.value.find(ct => ct.curso.id === courseId);
  if (!cursoTurnos) return;
  
  const allSelected = isCourseFullySelected(courseId);

  if (allSelected) {
    selectedShifts.value = selectedShifts.value.filter(id => 
      !cursoTurnos.turnos.some(turno => Number(turno.id) === Number(id))
    );
  } else {
    const turnosIds = cursoTurnos.turnos.map(turno => Number(turno.id));
    const currentSelected = new Set(selectedShifts.value.map(id => Number(id)));
    turnosIds.forEach(id => currentSelected.add(id));
    selectedShifts.value = Array.from(currentSelected);
  }

  verificarConflitos();
  
  const normalizedShifts = [...selectedShifts.value].map(id => Number(id));
  console.log("Emitindo seleção (toggle all):", normalizedShifts);
  emit("selection-change", normalizedShifts);
}

const getConflictDescription = (conflito) => {
  const curso1 = courses.value.find(c => c.id === conflito.turno1.courseId)
  const curso2 = courses.value.find(c => c.id === conflito.turno2.courseId)
  
  return `${curso1?.abbreviation || 'UC'} (${conflito.turno1.name}) e ${curso2?.abbreviation || 'UC'} (${conflito.turno2.name}) - ${getDiaSemana(conflito.dia)}, ${conflito.turno1.from}h-${conflito.turno1.to}h`
}

const publicarHorario = () => {
  if (conflitos.value.length > 0) {
    alert(`Atenção: Existem ${conflitos.value.length} conflitos no horário. Verifique antes de publicar.`)
  } else {
    alert("Horário publicado com sucesso!")
  }
}

const verPerfil = () => {
  router.push('/director/student/' + props.studentId)
}

const goBack = () => {
  router.back()
}

const initialSelectionLoaded = ref(false);

watch(
  () => props.studentId,
  (newVal) => {
    if (newVal) {
      fetchData()
      initialSelectionLoaded.value = false;
    }
  },
  { immediate: true }
)

watch(
  () => props.initialSelection,
  (newVal) => {
    if (newVal && newVal.length > 0) {
      console.log("initialSelection recebido:", newVal);
      
      // Convert all IDs to numbers for consistency
      selectedShifts.value = Array.isArray(newVal) 
        ? newVal.map(id => Number(id))
        : [];
        
      console.log("selectedShifts após atualização:", selectedShifts.value);
      verificarConflitos();
      expandSelectedCourses();
      initialSelectionLoaded.value = true;
    }
  },
  { deep: true, immediate: true }
);

onMounted(fetchData)
</script>
