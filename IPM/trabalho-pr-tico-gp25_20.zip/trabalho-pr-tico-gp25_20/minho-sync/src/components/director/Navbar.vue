<template>
  <div class="pt-[20px] px-[20px] pb-[0px]">
    <nav class="bg-red-800 text-white shadow-md rounded-lg">
      <div class="container mx-auto">
        <div class="flex justify-between items-center h-12 px-6 py-2">
          <!-- Logo e título -->
          <div class="flex items-center">
            <router-link to="/director/dashboard" class="flex items-center">
              <div class="flex items-center justify-center mr-2">
                <img src="/images/logotipo_branco.png" alt="Logo" class="h-8 w-8"/>
              </div>
              <span class="font-bold text-xl">MinhoSync</span>
            </router-link>
          </div>

          <!-- Links de navegação -->
          <div class="hidden md:flex items-center space-x-6">
            <router-link 
              to="/director/dashboard" 
              class="text-white hover:text-gray-300 transition-colors duration-200" 
              :class="{ 'font-bold': isActive('/director/dashboard') }"
            >
              Dashboard
            </router-link>
            <router-link 
              to="/director/schedule" 
              class="text-white hover:text-gray-300 transition-colors duration-200" 
              :class="{ 'font-bold': isActive('/director/schedule') }"
            >
              Horário Geral
            </router-link>
            <router-link 
              to="/director/manual-allocation" 
              class="text-white hover:text-gray-300 transition-colors duration-200" 
              :class="{ 'font-bold': isActive('/director/manual-allocation') }"
            >
              Gerir Turnos
            </router-link>
            <router-link 
              to="/director/requests" 
              class="text-white hover:text-gray-300 transition-colors duration-200" 
              :class="{ 'font-bold': isActive('/director/requests') }"
              >
              Pedidos
            </router-link>
          </div>

          <!-- Ícones à direita -->
          <div class="hidden md:flex items-center space-x-4">
            <!-- Ícone de notificações -->
            <div class="relative" ref="notificationsMenu">
              <button 
                @click="toggleNotificationsMenu" 
                class="p-1 rounded-lg bg-white hover:bg-gray-300 transition-colors duration-200 focus:outline-none relative"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="black">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <!-- Badge de notificações -->
                <div v-if="notificationCount > 0" class="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {{ notificationCount }}
                </div>
              </button>
              
              <!-- Menu de notificações - NOVO ESTILO -->
              <div 
                v-if="showNotificationsMenu" 
                class="absolute right-0 mt-2 w-96 bg-white rounded-b-lg shadow-xl pt-4 z-10"
              >
                <div class="px-6 py-2 flex items-center justify-between">
                  <div class="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                    <h2 class="text-2xl font-bold text-black">Notificações</h2>
                  </div>
                  <div v-if="notificationCount > 0" class="bg-red text-white rounded-full h-8 w-8 flex items-center justify-center">
                    {{ notificationCount }}
                  </div>
                </div>
                
                <!-- Lista de notificações -->
                <div class="max-h-70 overflow-y-auto px-4 mt-4">
                  <div 
                    v-for="notification in notifications" 
                    :key="notification.id" 
                    class="mb-3"
                  >
                    <div 
                      @click.prevent="navigateToRequest(notification)" 
                      class="bg-red-100 border border-dark-red rounded-lg p-4 cursor-pointer hover:bg-red-100 transition-colors duration-200"
                    >
                      <div class="flex justify-between items-start">
                        <div class="flex-1">
                          <p class="text-base font-medium text-gray-800">{{ notification.message }}</p>
                          <p class="text-sm text-gray-600 mt-1">Pedido por: {{ notification.requestedBy }}</p>
                          <p v-if="notification.reason" class="text-sm text-gray-600">Motivo: {{ notification.reason }}</p>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-dark-red ml-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  
                  <!-- Se não houver notificações -->
                  <div v-if="notifications.length === 0" class="px-4 py-6 text-center text-gray-500">
                    Não há notificações no momento.
                  </div>
                </div>
              </div>
            </div>

            <!-- Ícone de perfil / Logout -->
            <div class="relative">
              <button 
              @click="logout"
              class="p-1 rounded-lg bg-white hover:bg-gray-300 transition-colors duration-200 focus:outline-none"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="black">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </button>
            </div>
          </div>

          <!-- Menu mobile (hamburger) -->
          <div class="md:hidden">
            <button @click="toggleMobileMenu" class="p-1 rounded-full hover:bg-red-700 focus:outline-none">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path v-if="!mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <!-- Menu mobile expandido -->
        <div v-if="mobileMenuOpen" class="md:hidden">
          <div class="flex flex-col space-y-1">
            <router-link 
              to="/director/dashboard" 
              class="py-2 px-4 rounded hover:bg-red-700 transition-colors duration-200"
              :class="{ 'font-bold': isActive('/director/dashboard') }"
            >
              Dashboard
            </router-link>
            <router-link 
              to="/director/schedule" 
              class="py-2 px-4 rounded hover:bg-red-700 transition-colors duration-200"
              :class="{ 'font-bold': isActive('/director/schedule') }"
            >
              Horário Geral
            </router-link>
            <router-link 
              to="/director/manual-allocation" 
              class="py-2 px-4 rounded hover:bg-red-700 transition-colors duration-200"
              :class="{ 'font-bold': isActive('/director/manual-allocation') }"
            >
              Gerir Turnos
            </router-link>
            <router-link 
              to="/director/requests" 
              class="py-2 px-4 rounded hover:bg-red-700 transition-colors duration-200"
              :class="{ 'font-bold': isActive('/director/requests') }"
            >
              Pedidos
            </router-link>
            <a 
              href="#" 
              @click.prevent="logout" 
              class="py-2 px-4 rounded hover:bg-red-700 transition-colors duration-200"
            >
              Sair
            </a>
          </div>
        </div>
      </div>
    </nav>
  </div>
</template>
<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';

const route = useRoute();
const router = useRouter();
const mobileMenuOpen = ref(false);
const showNotificationsMenu = ref(false);
const notificationsMenu = ref(null);
const userName = ref('');

const classroomRequests = ref([]);
const shiftRequests = ref([]);
const shifts = ref([]);
const courses = ref([]);
const students = ref([]);
const teachers = ref([]);
const classrooms = ref([]);
const isLoading = ref(false);

const fetchRequests = async () => {
  isLoading.value = true;
  try {
    const classroomResponse = await axios.get('http://localhost:3000/classroomRequests');
    classroomRequests.value = classroomResponse.data;
    
    const shiftResponse = await axios.get('http://localhost:3000/shiftRequests');
    shiftRequests.value = shiftResponse.data;

    const shiftsResponse = await axios.get('http://localhost:3000/shifts');
    shifts.value = shiftsResponse.data;

    const coursesResponse = await axios.get('http://localhost:3000/courses');
    courses.value = coursesResponse.data;

    const studentsResponse = await axios.get('http://localhost:3000/students');
    students.value = studentsResponse.data;

    const teachersResponse = await axios.get('http://localhost:3000/teachers');
    teachers.value = teachersResponse.data;

    const classroomsResponse = await axios.get('http://localhost:3000/classrooms');
    classrooms.value = classroomsResponse.data;
  } catch (error) {
    console.error('Erro ao buscar pedidos:', error);
  } finally {
    isLoading.value = false;
  }
};

const getStudentName = (studentId) => {
  const student = students.value.find(s => s.id == studentId);
  return student ? student.name : `Aluno ${studentId}`;
};

const getTeacherName = (teacherId) => {
  const teacher = teachers.value.find(t => t.id == teacherId);
  return teacher ? teacher.name : `Professor ${teacherId}`;
};

const getShiftInfo = (shiftId) => {
  const shift = shifts.value.find(s => s.id == shiftId);
  if (!shift) return `Turno ${shiftId}`;
  
  const course = courses.value.find(c => c.id == shift.courseId);
  const courseName = course ? course.abbreviation || course.name : `Curso ${shift.courseId}`;
  
  return `Turno ${shift.name || shift.id}`;
};

const getCourseInfo = (shiftId) => {
  const shift = shifts.value.find(s => s.id == shiftId);
  if (!shift) return `Não encontrado`;
  
  const course = courses.value.find(c => c.id == shift.courseId);
  const courseName = course ? course.abbreviation || course.name : `Não encontrado`;
  
  return `${courseName}`;
};

const getClassroomName = (classroomId) => {
  const classroom = classrooms.value.find(c => c.id == classroomId);
  return classroom ? classroom.name : `Sala ${classroomId}`;
};

const pendingClassroomRequests = computed(() => {
  return classroomRequests.value.filter(req => 
    req.response === "" || (req.response !== "ok" && req.response !== "rejected")
  );
});

const pendingShiftRequests = computed(() => {
  return shiftRequests.value.filter(req => 
    req.response === "" || (req.response !== "ok" && req.response !== "rejected")
  );
});

const notifications = computed(() => {
  const classroomNotifications = pendingClassroomRequests.value.map(req => {
    const teacherName = getTeacherName(req.teacherId);
    const shiftInfo = getShiftInfo(req.shiftId);
    const toShiftInfo = getShiftInfo(req.shiftId);
    const courseName = getCourseInfo(req.shiftId);
    
    return {

      id: `${req.id}`,
      type: 'classroom',
      reason: req.reason,
      message: `Mudar ${toShiftInfo} para sala diferente - ${courseName}`,
      requestedBy: teacherName,
      date: req.date,
      requestId: req.id,
      originalRequest: req
    };
  });

  const shiftNotifications = pendingShiftRequests.value.map(req => {
    const studentName = getStudentName(req.studentId);
    const fromShiftInfo = getShiftInfo(req.fromShiftId);
    const toShiftInfo = getShiftInfo(req.shiftId);
    const courseName = getCourseInfo(req.fromShiftId);

    return {
      id: `${req.id}`,
      type: 'shift',
      message: `Pedido para mudar de ${fromShiftInfo} para ${toShiftInfo} - ${courseName}`,
      requestedBy: studentName,
      reason: req.reason,
      date: req.date,
      requestId: req.id,
      originalRequest: req
    };
  });

  return [...classroomNotifications, ...shiftNotifications];
});

const notificationCount = computed(() => notifications.value.length);

const isActive = (path) => {
  return route.path === path || route.path.startsWith(`${path}/`);
};

const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value;
  if (mobileMenuOpen.value) {
    showNotificationsMenu.value = false;
  }
};

const toggleNotificationsMenu = () => {
  showNotificationsMenu.value = !showNotificationsMenu.value;
};

const handleClickOutside = (event) => {
  if (notificationsMenu.value && !notificationsMenu.value.contains(event.target)) {
    showNotificationsMenu.value = false;
  }
};

const navigateToRequest = (notification) => {
  if (notification.type === 'classroom') {
    router.push(`/director/requests/classroom/${notification.requestId}`);
  } else if (notification.type === 'shift') {
    router.push(`/director/requests/shift/${notification.requestId}`);
  }
};

const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('userType');
  localStorage.removeItem('userId');
  localStorage.removeItem('userName');
  
  router.push('/login');
};

const storedName = localStorage.getItem('userName') || '';
userName.value = storedName;

onMounted(() => {
  document.addEventListener('click', handleClickOutside);
  
  fetchRequests();
  
  const interval = setInterval(fetchRequests, 30000);
  
  return () => {
    document.removeEventListener('click', handleClickOutside);
    clearInterval(interval);
  };
});

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside);
});
</script>